<?PHP
include "../config.php";
class clientC {
function afficherclient ($client){
		echo "Cin: ".$client->getCin()."<br>";
		echo "Nom: ".$client->getNom()."<br>";
		echo "Prénom: ".$client->getPrenom()."<br>";
		echo "tel: ".$client->gettel()."<br>";
		echo "adress: ".$client->getadress()."<br>";
	}

	function ajouterclient($client){
		$sql="insert into client (cin,nom,prenom,tel,adress) values (:cin, :nom,:prenom,:tel,:adress)";
		$db = config::getConnexion();
		try{
        $req=$db->prepare($sql);
		
        $cin=$client->getCin();
        $nom=$client->getNom();
        $prenom=$client->getPrenom();
        $tel=$client->gettel();
        $adress=$client->getadress();
		$req->bindValue(':cin',$cin);
		$req->bindValue(':nom',$nom);
		$req->bindValue(':prenom',$prenom);
		$req->bindValue(':tel',$tel);
		$req->bindValue(':adress',$adress);
		
            $req->execute();
           
        }
        catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
		
	}
	
	function afficherclients(){
		//$sql="SElECT * From client e inner join formationphp.client a on e.cin= a.cin";
		$sql="SElECT * From client";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }	
	}
	function supprimerclient($cin){
		$sql="DELETE FROM client where cin= :cin";
		$db = config::getConnexion();
        $req=$db->prepare($sql);
		$req->bindValue(':cin',$cin);
		try{
            $req->execute();
           // header('Location: index.php');
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	function modifierclient($client,$cin){
		$sql="UPDATE client SET cin=:cinn, nom=:nom,prenom=:prenom,tel=:tel,adress=:adress WHERE cin=:cin";
		
		$db = config::getConnexion();
		//$db->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);
try{		
        $req=$db->prepare($sql);
		$cinn=$client->getCin();
        $nom=$client->getNom();
        $prenom=$client->getPrenom();
        $tel=$client->gettel();
        $adress=$client->getadress();
		$datas = array(':cinn'=>$cinn, ':cin'=>$cin, ':nom'=>$nom,':prenom'=>$prenom,':tel'=>$tel,':adress'=>$adress);
		$req->bindValue(':cinn',$cinn);
		$req->bindValue(':cin',$cin);
		$req->bindValue(':nom',$nom);
		$req->bindValue(':prenom',$prenom);
		$req->bindValue(':tel',$tel);
		$req->bindValue(':adress',$adress);
		
		
            $s=$req->execute();
			
           // header('Location: index.php');
        }
        catch (Exception $e){
            echo " Erreur ! ".$e->getMessage();
   echo " Les datas : " ;
  print_r($datas);
        }
		
	}
	function recupererclient($cin){
		$sql="SELECT * from client where cin=$cin";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	
	function rechercherListeclients($cin){
		$sql="SELECT * from client where cin=$cin";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}


	function afficherDESC()
     {
    $sql="select * from client ORDER BY nom DESC";
    $db = config::getConnexion();
    return ($db->query($sql));
    
     }

   function afficherASC()
   {
    $sql="select * from client ORDER BY nom ASC";
    $db = config::getConnexion();
    return ($db->query($sql));
    }
    

}

?>