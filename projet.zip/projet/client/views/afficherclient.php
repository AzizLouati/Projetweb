<?PHP
include "../core/clientC.php";
$client1C=new clientC();
$listeclients=$client1C->afficherclients();

//var_dump($listeclients->fetchAll());
?>
<table border="1">
<tr>
<td>Cin</td>
<td>Nom</td>
<td>Prenom</td>
<td>tel</td>
<td>adress</td>
<td>supprimer</td>
<td>modifier</td>
<td>ajouter</td>
</tr>

<?PHP
foreach($listeclients as $row){
	?>
	<tr>
	<td><?PHP echo $row['cin']; ?></td>
	<td><?PHP echo $row['nom']; ?></td>
	<td><?PHP echo $row['prenom']; ?></td>
	<td><?PHP echo $row['tel']; ?></td>
	<td><?PHP echo $row['adress']; ?></td>
	<td><form method="POST" action="supprimerclient.php">
	<input type="submit" name="supprimer" value="supprimer">
	<input type="hidden" value="<?PHP echo $row['cin']; ?>" name="cin">
	</form>
	</td>
<td><a href="modifierclient.php?cin=<?PHP echo $row['cin']; ?>">
	Modifier</a></td>
	
	<td><form method="POST" action="ajoutclient.html">
		<input type="submit" name="ajouter" value="ajouter">
	</form>
	</td>
	</tr>
	<?PHP
}
?>
</table>


