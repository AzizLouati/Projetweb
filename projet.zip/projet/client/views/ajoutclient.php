<?PHP
include "../entities/client.php";
include "../core/clientC.php";

if (isset($_POST['cin']) and isset($_POST['nom']) and isset($_POST['prenom']) and isset($_POST['tel']) and isset($_POST['adress'])){
$client1=new client($_POST['cin'],$_POST['nom'],$_POST['prenom'],$_POST['tel'],$_POST['adress']);
//Partie2
/*
var_dump($client1);
}
*/
//Partie3
$client1C=new clientC();
$client1C->ajouterclient($client1);
header('Location: afficherclient.php');
	
}else{
	echo "vérifier les champs";
}
//*/

?>