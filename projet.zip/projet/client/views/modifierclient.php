<HTML>
<head>
</head>
<body>
<?PHP
include "../entities/client.php";
include "../core/clientC.php";
if (isset($_GET['cin'])){
	$clientC=new clientC();
    $result=$clientC->recupererclient($_GET['cin']);
	foreach($result as $row){
		$cin=$row['cin'];
		$nom=$row['nom'];
		$prenom=$row['prenom'];
		$tel=$row['tel'];
		$adress=$row['adress'];
?>
<form method="POST">
<table>
<caption>Modifier client</caption>
<tr>
<td>CIN</td>
<td><input type="number" name="cin" value="<?PHP echo $cin ?>"></td>
</tr>
<tr>
<td>Nom</td>
<td><input type="text" name="nom" value="<?PHP echo $nom ?>"></td>
</tr>
<tr>
<td>Prenom</td>
<td><input type="text" name="prenom" value="<?PHP echo $prenom ?>"></td>
</tr>
<tr>
<td>nb heures</td>
<td><input type="number" name="tel" value="<?PHP echo $tel ?>"></td>
</tr>
<tr>
<td>tarif horaire</td>
<td><input type="text" name="adress" value="<?PHP echo $adress ?>"></td>
</tr>
<tr>
<td></td>
<td><input type="submit" name="modifier" value="modifier"></td>
</tr>
<tr>
<td></td>
<td><input type="hidden" name="cin_ini" value="<?PHP echo $_GET['cin'];?>"></td>
</tr>
</table>
</form>
<?PHP
	}
}
if (isset($_POST['modifier'])){
	$client=new client($_POST['cin'],$_POST['nom'],$_POST['prenom'],$_POST['tel'],$_POST['adress']);
	$clientC->modifierclient($client,$_POST['cin_ini']);
	echo $_POST['cin_ini'];
	header('Location: afficherclient.php');
}
?>
</body>
</HTMl>