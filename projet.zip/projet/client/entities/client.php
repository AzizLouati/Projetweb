<?PHP
class client{
	private $cin;
	private $nom;
	private $prenom;
	private $tel;
	private $adress;
	function __construct($cin,$nom,$prenom,$tel,$adress){
		$this->cin=$cin;
		$this->nom=$nom;
		$this->prenom=$prenom;
		$this->tel=$tel;
		$this->adress=$adress;
	}
	
	function getCin(){
		return $this->cin;
	}
	function getNom(){
		return $this->nom;
	}
	function getPrenom(){
		return $this->prenom;
	}
	function gettel(){
		return $this->tel;
	}
	function getadress(){
		return $this->adress;
	}

	function setNom($nom){
		$this->nom=$nom;
	}
	function setPrenom($prenom){
		$this->prenom;
	}
	function settel($tel){
		$this->tel=$tel;
	}
	function setadress($adress){
		$this->adress=$adress;
	}
	
}

?>