<?PHP
class promotion{
	private $idproduit;
	private $nomproduit;
	private $promotionproduit;
	function __construct($idproduit,$nomproduit,$promotionproduit){
		$this->idproduit=$idproduit;
		$this->nomproduit=$nomproduit;
		$this->promotionproduit=$promotionproduit;
	}
	
	function getidproduit(){
		return $this->idproduit;
	}
	function getnomproduit(){
		return $this->nomproduit;
	}
	function getpromotionproduit(){
		return $this->promotionproduit;
	}

	function setnomproduit($nomproduit){
		$this->nomproduit=$nomproduit;
	}
	function setpromotionproduit($promotionproduit){
		$this->promotionproduit;
	}
		
}

?>