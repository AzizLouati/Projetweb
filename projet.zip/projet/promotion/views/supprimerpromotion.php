<?PHP
include "../core/promotionC.php";
$promotionC=new promotionC();
if (isset($_POST["cin"])){
	$promotionC->supprimerpromotion($_POST["cin"]);
	header('Location: afficherpromotion.php');
}

?>