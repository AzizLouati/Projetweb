<?PHP
include "../core/promotionC.php";
$promotion1C=new promotionC();
$listepromotions=$promotion1C->afficherpromotions();

//var_dump($listepromotions->fetchAll());
?>
<table border="1">
<tr>
<td>idproduit</td>
<td>nomproduit</td>
<td>promotionproduit</td>
<td>supprimer</td>
<td>modifier</td>
<td>ajouter</td>
</tr>

<?PHP
foreach($listepromotions as $row){
	?>
	<tr>
	<td><?PHP echo $row['idproduit']; ?></td>
	<td><?PHP echo $row['nomproduit']; ?></td>
	<td><?PHP echo $row['promotionproduit']; ?></td>
	<td><form method="POST" action="supprimerpromotion.php">
	<input type="submit" name="supprimer" value="supprimer">
	<input type="hidden" value="<?PHP echo $row['idproduit']; ?>" name="idproduit">
	</form>
	</td>
<td><a href="modifierpromotion.php?idproduit=<?PHP echo $row['idproduit']; ?>">
	Modifier</a></td>
	
	<td><form method="POST" action="ajoutpromotion.html">
		<input type="submit" name="ajouter" value="ajouter">
	</form>
	</td>
	</tr>
	<?PHP
}
?>
</table>


