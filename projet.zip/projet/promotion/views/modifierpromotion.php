<HTML>
<head>
</head>
<body>
<?PHP
include "../entities/promotion.php";
include "../core/promotionC.php";
if (isset($_GET['idproduit'])){
	$promotionC=new promotionC();
    $result=$promotionC->recupererpromotion($_GET['idproduit']);
	foreach($result as $row){
		$idproduit=$row['idproduit'];
		$nomproduit=$row['nomproduit'];
		$promotionproduit=$row['promotionproduit'];
?>
<form method="POST">
<table>
<caption>Modifier promotion</caption>
<tr>
<td>idproduit</td>
<td><input type="number" name="idproduit" value="<?PHP echo $idproduit ?>"></td>
</tr>
<tr>
<td>nomproduit</td>
<td><input type="text" name="nomproduit" value="<?PHP echo $nomproduit ?>"></td>
</tr>
<tr>
<td>promotionproduit</td>
<td><input type="text" name="promotionproduit" value="<?PHP echo $promotionproduit ?>"></td>
</tr>
<tr>
<td></td>
<td><input type="submit" name="modifier" value="modifier"></td>
</tr>
<tr>
<td></td>
<td><input type="hidden" name="idproduit_ini" value="<?PHP echo $_GET['idproduit'];?>"></td>
</tr>
</table>
</form>
<?PHP
	}
}
if (isset($_POST['modifier'])){
	$promotion=new promotion($_POST['idproduit'],$_POST['nomproduit'],$_POST['promotionproduit']);
	$promotionC->modifierpromotion($promotion,$_POST['idproduit_ini']);
	echo $_POST['idproduit_ini'];
	header('Location: afficherpromotion.php');
}
?>
</body>
</HTMl>