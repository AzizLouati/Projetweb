<?PHP
include "../entities/promotion.php";
include "../core/promotionC.php";

if (isset($_POST['idproduit']) and isset($_POST['nomproduit']) and isset($_POST['Promotionproduit'])  ){
$promotion1=new promotion($_POST['idproduit'],$_POST['nomproduit'],$_POST['Promotionproduit']);
//Partie2
/*
var_dump($promotion1);
}
*/
//Partie3
$promotion1C=new promotionC();
$promotion1C->ajouterpromotion($promotion1);
header('Location: afficherpromotion.php');
	
}else{
	echo "vérifier les champs";
}
//*/

?>