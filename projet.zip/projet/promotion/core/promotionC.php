<?PHP
include "../config.php";
class promotionC {
function afficherpromotion ($promotion){
		echo "idproduit: ".$promotion->getidproduit()."<br>";
		echo "nomproduit: ".$promotion->getnomproduit()."<br>";
		echo "promotionproduit: ".$promotion->getPrenomproduit()."<br>";
	}

	function ajouterpromotion($promotion){
		$sql="insert into promotion (idproduit,nomproduit,prenomproduit) values (:idproduit, :nomproduit,:prenomproduit)";
		$db = config::getConnexion();
		try{
        $req=$db->prepare($sql);
		
        $idproduit=$promotion->getidproduit();
        $nomproduit=$promotion->getnomproduit();
        $prenomproduit=$promotion->getPrenomproduit();
		$req->bindValue(':idproduit',$idproduit);
		$req->bindValue(':nomproduit',$nomproduit);
		$req->bindValue(':prenomproduit',$prenomproduit);
		
            $req->execute();
           
        }
        catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
		
	}
	
	function afficherpromotions(){
		//$sql="SElECT * From promotion e inner join formationphp.promotion a on e.idproduit= a.idproduit";
		$sql="SElECT * From promotion";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }	
	}
	function supprimerpromotion($idproduit){
		$sql="DELETE FROM promotion where idproduit= :idproduit";
		$db = config::getConnexion();
        $req=$db->prepare($sql);
		$req->bindValue(':idproduit',$idproduit);
		try{
            $req->execute();
           // header('Location: index.php');
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	function modifierpromotion($promotion,$idproduit){
		$sql="UPDATE promotion SET idproduit=:idproduitn, nomproduit=:nomproduit,prenomproduit=:prenomproduit WHERE idproduit=:idproduit";
		
		$db = config::getConnexion();
		//$db->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);
try{		
        $req=$db->prepare($sql);
		$idproduitn=$promotion->getidproduit();
        $nomproduit=$promotion->getnomproduit();
        $prenomproduit=$promotion->getPrenomproduit();
		$datas = array(':idproduitn'=>$idproduitn, ':idproduit'=>$idproduit, ':nomproduit'=>$nomproduit,':prenomproduit'=>$prenomproduit);
		$req->bindValue(':idproduitn',$idproduitn);
		$req->bindValue(':idproduit',$idproduit);
		$req->bindValue(':nomproduit',$nomproduit);
		$req->bindValue(':prenomproduit',$prenomproduit);
		
		
            $s=$req->execute();
			
           // header('Location: index.php');
        }
        catch (Exception $e){
            echo " Erreur ! ".$e->getMessage();
   echo " Les datas : " ;
  print_r($datas);
        }
		
	}
	function recupererpromotion($idproduit){
		$sql="SELECT * from promotion where idproduit=$idproduit";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	
	function rechercherListepromotions($promotionproduit){
		$sql="SELECT * from promotion where promotionproduit=$promotionproduit";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
}

?>