<?php
class user{
	private $id;
	private $nom;
	private $prenom;
	private $mot_de_passe;
	function __construct($id,$nom,$prenom,$mot_de_passe){
		$this->id=$id;
		$this->nom=$nom;
		$this->prenom=$prenom;
		$this->mot_de_passe=$mot_de_passe;
	}
	function getid(){
		return $this->id;
	}
	function getnom(){
		return $this->nom;
	}
	function getprenom(){
		return $this->prenom;
	}
	function getmot_de_passe(){
		return $this->mot_de_passe;
	}
	function setnom($nom){
		$this->nom=$nom;
	}
	function setprenom($prenom){
		$this->prenom;
	}
	
	function setmot_de_passe($mot_de_passe){
		$this->mot_de_passe=$mot_de_passe;
	}
	
}


?>