<?php
class article
{
	private $ref;
	private $nom;
	private $prix;
	private $couleur_disponibe;
	private $photo;
	public function __construct($ref,$nom,$prix,$couleur_disponible,$photo) /*constructeur*/
	{
		$this->ref=$ref;$this->nom=$nom;$this->prix=$prix;$this->couleur_disponible=$couleur_disponible;$this->photo=$photo;
	
	}
	public function getref() {return $this->ref;}
	public function setref($ref) {$this->ref=$ref;}
	public function getnom() {return $this->nom;}
	public function setnom($nom) {$this->nom=$nom;}
	public function getprix() {return $this->prix;}
	public function setprix($prix) {$this->prix=$prix;}
	public function getcouleur_disponible() {return $this->couleur_disponible;}
	public function setcouleur_disponible($couleur_disponible) {$this->couleur_disponible=$couleur_disponible;}
	public function getphoto() {return $this->photo;}
	public function setphoto($photo) {$this->photo=$photo;}
	
	
}