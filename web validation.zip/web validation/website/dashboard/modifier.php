 <?php
 session_start();
 include "C:/wamp64/www/website/dashboard/article/core/articlec.php";
  include "C:/wamp64/www/website/dashboard/article/Entities/article.php";
  if (isset($_POST['mod'])){
	$articlec=new articlec();
	$article=new article($_POST['ref'],$_POST['nom'],$_POST['prix'],$_POST['couleur_disponible'],"");
	$articlec->modifierarticle($article,$_SESSION['refff']);
	echo "<script>
alert('Succes');
window.location.href='./afficher_article.php';
</script>";
  }
  ?>
  
	
	