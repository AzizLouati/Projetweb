<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>
    Liste des clients
  </title>

   <!-- Favicon -->
  <link href="./assets/img/brand/favicon.png" rel="icon" type="image/png">
  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
  <!-- Icons -->
  <link href="./assets/js/plugins/nucleo/css/nucleo.css" rel="stylesheet" />
  <link href="./assets/js/plugins/@fortawesome/fontawesome-free/css/all.min.css" rel="stylesheet" />
  <!-- CSS Files -->
  <link href="./assets/css/argon-dashboard.css?v=1.1.2" rel="stylesheet" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

  <script type="text/javascript">
          function printDiv(divName) {
            var printContents = document.getElementById(divName).innerHTML;
            var originalContents = document.body.innerHTML;

            document.body.innerHTML = printContents;
            window.print();
            document.body.innerHTML = originalContents;
        }

         function trierPar()
         {
          var input = document.getElementById("tri").value  ;
          window.location="listeClient.php?tri="+input;
        }
       </script>
</head>

<body class="">

 <!-- Header -->

        <div class="">
        <?php
           include "headerback.php" ;
           include '../core/clientC.php';
           $clt = new ClientC() ;
           $list=$clt->afficherClient() ; 
           if(isset($_GET['search']))
             {
              $list = $clt->rechercherClient($_GET['search']) ;
             }
          if (!empty($list)) {  ?> 
          <div class="cont" id="divClient">
             <!--<table class="table dark-table" style="margin: auto;width: 95%;text-align: center;" >-->  
             <div class="header bg-gradient-primary pb-8 pt-5 pt-md-8">
 
             <!--<caption><h1> </h1></caption><br><br><br><br> 
              <input type="search" name="search" id="rechercher" onsearch="rechercher() ;" style="margin-bottom: 50px;width: 40%;height: 40px;">  -->

            <div class="container-fluid">
          
             <h3 id="dark-table">Liste des Clients</h3><br>
             <div>

              <div class="tab-content">
                <div id="table-dark-component" class="tab-pane tab-example-result fade show active" role="tabpanel" aria-labelledby="table-dark-component-tab">

                  <form class="navbar-search navbar-search-dark form-inline mr-3 d-none d-md-flex ml-lg-auto">
                    <div class="form-group mb-0">
                      <div class="input-group input-group-alternative">
                        <div class="input-group-prepend">
                          <span class="input-group-text"><i class="fas fa-search"></i></span>
                        </div>
                          <input class="form-control" placeholder="Search" type="search" name="search" id="rechercher" onsearch="rechercher() ;"><br><br>
                      </div>
                    </div>
                    <div class="print">
                        <select id="tri" onchange="trierPar();"> 
                            <option value="0">-- Filtrer par --</option>
                            <option value="id_up">Id Croissant</option>
                            <option value="id_down">Id Decroissant</option>
                            <option value="name_up">Nom A .. Z</option>
                            <option value="name_down">Nom Z .. A</option>
                          </select>
                          <i class="fa fa-print "  style="margin-right: 50px; font-size: 28px; " onclick="printDiv('divClient');"></i>
                    </div>
                </div>
                  </form>
                        <?php
           $cltC = new ClientC() ;
           $mylist=$cltC->afficherClient() ; 
           if(isset($_GET['search']))
             {
              $mylist = $cltC->rechercherClient($_GET['search']) ;
             }

            if(isset($_GET['tri']))
             {
              if($_GET['tri'] == "id_up")
              {
                $mylist= $cltC->TrierClient('id','asc') ;
              }
              else if($_GET['tri'] == "id_down")
              {
                $mylist= $cltC->TrierClient('id','desc') ;
              }
              else if($_GET['tri'] == "name_up")
              {
                $mylist= $cltC->TrierClient('nom','asc') ;
              }
              else if($_GET['tri'] == "name_down")
              {
                $mylist= $cltC->TrierClient('nom','desc') ;
              }
              
             }
         if (!empty($mylist)) {  ?>
          
              <table class="table align-items-center table-dark">
                    <thead class="thead-dark"> 

             
                  <th>ID </th>
                  <th>Nom</th>
                  <th>Prenom</th>
                  <th>Email</th>
                  <th>Mot de Passe</th>
                  <th>Addresse</th>
                  <th>Telephone </th>
                  <th>Action</th>
                </thead>
             <tbody>
              <?php
                  foreach ($mylist as $row) {
              ?>
              <tr>
                <td><?php echo $row['id'] ; ?></td>
                <td><?php echo $row['nom'] ; ?></td>
                <td><?php echo $row['prenom']; ?> </td>
                <td><?php echo $row['email'] ; ?></td>
                <td><?php echo $row['password'] ; ?></td>
                <td><?php echo $row['address'] ; ?></td>
                <td><?php echo $row['phone'] ; ?></td>
                <td><a href="supprimerClient.php?id=<?PHP echo $row['id']; ?>"><i class="fa fa-trash-o m-r-5"></i></a></td>
              </tr>
            <?php
                      }
 
                 }
            ?>
                  <caption><h1> </h1></caption><br><br>
                 
                
          <?php
           }
          ?>
        </tbody>
      </table>
       <?php
           
          ?>
      </div>
  </div>

  <script type="text/javascript">
         function rechercher(){
          var input = document.getElementById("rechercher").value ;
          window.location="listeClient.php?search="+input; 
         }
       </script>

         </table>
                </div>
              </div>
            </div>
           
      
                </div>
                 
           
        </div>


</body>
</html>