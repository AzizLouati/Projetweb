<?php
class payement
{
	
	private $idclient;
	private $nom;
	private $email;
	
	private $num_cart;
	private $date_cart;
	private $cvc;
	
	function __construct($idclient,$nom,$email,$num_cart,$date_cart,$cvc)
	{
		$this->idclient=$idclient;
		$this->nom=$nom;
		$this->email=$email;
		
		$this->num_cart=$num_cart;
		$this->date_cart=$date_cart;
		$this->cvc=$cvc;
	}

	function getid()
	{
		return $this->idclient;	
	}


	function getnom()
	{
		return $this->nom;	
	}

	function getemail()
	{
		return $this->email;	
	}

	
	function getnum()
	{
		return $this->num_cart;	
	}

	

function getDateC()
	{
		return $this->date_cart;	
	}

function getcvc()
	{
		return $this->cvc;	
	}

	
	function setid($idclient)
	{
		return $this->idclient=$idclient;	
	}


	function setnom($nom)
	{
		return $this->nom=$nom;	
	}

	function setemail($email)
	{
		return $this->email=$email;	
	}

	
	function getnum($num_cart)
	{
		return $this->num_cart=$num_cart;	
	}

	function getDateC($date_cart)
	{
		return $this->date_cart=$date_cart;	
	}



function setcvc($cvc)
	{
		return $this->cvc=$cvc;	
	}

	
	

	
}
?>