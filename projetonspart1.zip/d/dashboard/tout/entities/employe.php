<?PHP
class Actualite{
	private $numActualite;
	private $titre;
	private $image;
		private $date_actualite   ;
			private $description;
	function __construct($numActualite,$titre,$image,$date_actualite,$description){
		$this->numActualite=$numActualite;
		$this->titre=$titre;
		$this->image=$image;
		$this->date_actualite=$date_actualite;
	
		$this->description=$description;
	
		}
	
	function getnumActualite(){
		return $this->numActualite;
	}
	function gettitre(){
		return $this->titre;
	}
	function getimage(){
		return $this->image;
	}
	function getdate(){
		return $this->date_actualite;
	}
	function getDescription(){
		return $this->description;
	}
	function setnumActualite($numActualite){
		$this->numActualite=$numActualite;
	}
	function settitre($titre){
		$this->titre=$titre;
	}
	function setimage(){
	$this->image=$image;	
	}
	function setdate(){
	$this->date_actualite=$date_actualite;	
	}
	function setDescription(){
	$this->description=$description;	
	}
}

?>