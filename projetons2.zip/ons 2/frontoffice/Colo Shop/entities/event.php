<?php

class event
{
	
	private $reference;
	private $titre;
	private $description;
	private $datefin;
	private $datedebut;
	private $image;
	
	
	function __construct($reference,$titre,$image,$datedebut,$datefin,$description)
	{
		$this->reference=$reference;
		$this->titre=$titre;
		$this->description=$description;
		$this->datefin=$datefin;
		$this->datedebut=$datedebut;
		$this->image=$image;
		
	}

	function getReference()
	{
		return $this->reference;	
	}


	function getTitre()
	{
		return $this->titre;	
	}

	function getDescription()
	{
		return $this->description;	
	}

	
	function getDateevent()
	{
		return $this->datefin;	
	}
function getDateevente()
	{
		return $this->datedebut;	
	}
	function getImage()
	{
		return $this->image;	
	}




	function setReference($reference)
	{
		$this->reference=$reference;	
	}
    

	function setTitre($titre)
	{
		$this->titre=$titre;	
	}
    

	function setDescription($description)
	{
		 $this->description=$description;	
	}
	function setType($type)
	{
		$this->type=$type;	
	}
	function setDateevent($datefin)
	{
		$this->datefin=$datefin;	
	}
	function setImage($image)
	{
		$this->image=$image;	
	}	
	
	

	
}
?>