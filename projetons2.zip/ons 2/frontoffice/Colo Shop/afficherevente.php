

<!DOCTYPE html>
<html lang="en">
<head>
<title>afficher</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="description" content="Colo Shop Template">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="styles/bootstrap4/bootstrap.min.css">
<link href="plugins/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/owl.carousel.css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/owl.theme.default.css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/animate.css">
<link rel="stylesheet" href="plugins/themify-icons/themify-icons.css">
<link rel="stylesheet" type="text/css" href="plugins/jquery-ui-1.12.1.custom/jquery-ui.css">
<link rel="stylesheet" type="text/css" href="styles/ajoutv.css">
<link rel="stylesheet" type="text/css" href="styles/ajoutv_responsive.css">
</head>

<body>

<div class="super_container">

  <!-- Header -->

  <header class="header trans_300">

    <!-- Top Navigation -->

    <div class="top_nav">
      <div class="container">
        <div class="row">
          <div class="col-md-6">
            <div class="top_nav_left">free shipping on all u.s orders over $50</div>
          </div>
          <div class="col-md-6 text-right">
            <div class="top_nav_right">
              <ul class="top_nav_menu">

                <!-- Currency / Language / My Account -->

                <li class="currency">
                  <a href="#">
                    usd
                    <i class="fa fa-angle-down"></i>
                  </a>
                  <ul class="currency_selection">
                    <li><a href="#">cad</a></li>
                    <li><a href="#">aud</a></li>
                    <li><a href="#">eur</a></li>
                    <li><a href="#">gbp</a></li>
                  </ul>
                </li>
                <li class="language">
                  <a href="#">
                    English
                    <i class="fa fa-angle-down"></i>
                  </a>
                  <ul class="language_selection">
                    <li><a href="#">French</a></li>
                    <li><a href="#">Italian</a></li>
                    <li><a href="#">German</a></li>
                    <li><a href="#">Spanish</a></li>
                  </ul>
                </li>
                <li class="account">
                  <a href="#">
                    <?php echo $row['nom'];?>
                    <i class="fa fa-angle-down"></i>
                  </a>
                  <ul class="account_selection">
                    <li><a href="#"><i class="fa fa-sign-in" aria-hidden="true"></i>Sign In</a></li>
                    <li><a href="#"><i class="fa fa-user-plus" aria-hidden="true"></i>Register</a></li>
                  </ul>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Main Navigation -->

    <div class="main_nav_container">
      <div class="container">
        <div class="row">
          <div class="col-lg-12 text-right">
            <div class="logo_container">
              <a href="#">patch<span>work</span></a>
            </div>
            <nav class="navbar">
              <ul class="navbar_menu">
                <li><a href="indextry.html">home</a></li>
                <li><a href="single.html">shop</a></li>
                <li><a href="#">promotion</a></li>
                <li><a href="#">pages</a></li>
                <li><a href="#">blog</a></li>
                <li><a href="contact.html">contact</a></li>
                
              </ul>
              <ul class="navbar_user">
                <li><a href="#"><i class="fa fa-search" aria-hidden="true"></i></a></li>
                <li><a href="#"><i class="fa fa-user" aria-hidden="true"></i></a></li>
                <li class="checkout">
                  <a href="#">
                    <i class="fa fa-shopping-cart" aria-hidden="true"></i>
                    <span id="checkout_items" class="checkout_items">2</span>
                  </a>
                </li>
              </ul>
              <div class="hamburger_container">
                <i class="fa fa-bars" aria-hidden="true"></i>
              </div>
            </nav>
          </div>
        </div>
      </div>
    </div>

  </header>

  <div class="fs_menu_overlay"></div>

  <!-- Hamburger Menu -->

  <div class="hamburger_menu">
    <div class="hamburger_close"><i class="fa fa-times" aria-hidden="true"></i></div>
    <div class="hamburger_menu_content text-right">
      <ul class="menu_top_nav">
        <li class="menu_item has-children">
          <a href="#">
            usd
            <i class="fa fa-angle-down"></i>
          </a>
          <ul class="menu_selection">
            <li><a href="#">cad</a></li>
            <li><a href="#">aud</a></li>
            <li><a href="#">eur</a></li>
            <li><a href="#">gbp</a></li>
          </ul>
        </li>
        <li class="menu_item has-children">
          <a href="#">
            English
            <i class="fa fa-angle-down"></i>
          </a>
          <ul class="menu_selection">
            <li><a href="#">French</a></li>
            <li><a href="#">Italian</a></li>
            <li><a href="#">German</a></li>
            <li><a href="#">Spanish</a></li>
          </ul>
        </li>
        <li class="menu_item has-children">
          <a href="#">
            My Account
            <i class="fa fa-angle-down"></i>
          </a>
          <ul class="menu_selection">
            <li><a href="loginclient.html"><i class="fa fa-sign-in" aria-hidden="true"></i>Sign In</a></li>
            <li><a href="#"><i class="fa fa-user-plus" aria-hidden="true"></i>Register</a></li>
          </ul>
        </li>
        <li class="menu_item"><a href="indextry.html">home</a></li>
        <li class="menu_item"><a href="single.html">shop</a></li>
        <li class="menu_item"><a href="#">promotion</a></li>
        <li class="menu_item"><a href="#">pages</a></li>
        <li class="menu_item"><a href="#">blog</a></li>
        <li class="menu_item"><a href="contact.html">contact</a></li>
        
      </ul>
    </div>
  </div>

  <div class="container contact_container">
    <div class="row">
      <div class="col">

        <!-- Breadcrumbs -->

        <div class="breadcrumbs d-flex flex-row align-items-center">
          <ul>
            <li><a href="indextry.html">Home</a></li>
            <!--<li><a href="ajouter_articlev.html " class="fa fa-angle-right" aria-hidden="true">Ajout</a></li>-->
          
            <li class="active"><a href="#"><i class="fa fa-angle-right" aria-hidden="true"></i>les evenements </a></li>
            
          </ul>
        </div>
          <div>
          <!--<a href="ajouter_articlev.html"><button class="btn btn-info btn-xs" name="sup">ajouter</button></a></div>-->
          
      </div>
    </div>

    <!-- End Navbar -->
    <!-- Header -->

<?PHP
include "C:/wamp6/www/d/frontoffice/Colo Shop/core/eventC.php";
$event1C=new eventC();
$listeevents=$event1C->afficherevents();

//var_dump($listeEmployes->fetchAll());

                 if(isset($_GET['search']))
           {
            $listeevents = $event1C->rechercherListeevent($_GET['search']) ;
             
           }

         if (!empty($listeevents)) {?>

</table>
      <div class="container-fluid">
     <div class="form-group">
                            <input class="form-control" type="search" name="rechercher" id="rechercher" onsearch="rechercher();" placeholder="rechercher ...">
      <div class="container-fluid">
	  
	     <h3 id="dark-table"></h3>
        <div>
         
          <div class="tab-content">
            <div id="table-dark-component" class="tab-pane tab-example-result fade show active" role="tabpanel" aria-labelledby="table-dark-component-tab">
              <div >
                <div>
                  <table class="table align-items-center table-dark">
                    <thead class="thead-dark">
                      <tr>
 
                                            
 <th scope="col" class="sort" data-sort="budget">Titre</th>
                      
 <th scope="col" class="sort" data-sort="status">image</th>
  <th scope="col" class="sort" data-sort="status">date_debut</th>   
           <th scope="col" class="sort" data-sort="status">date_fin</th>               
		 <th scope="col" class="sort" data-sort="status">Description</th> 			

                      </tr>
                    </thead>
                    <tbody >


<?PHP
foreach($listeevents as $row){
	?>
	<tr>
	
	<td><?PHP echo $row['titre']; ?></td>
	
		<td><a><img class="" src="docs/<?php echo $row['image'];?>" style="width: 100px; height:100px;"></a></td>
<td><?PHP echo $row['datedebut']; ?></td> 
  <td><?PHP echo $row['datefin']; ?></td> 
  
	<td><?PHP echo $row['description']; ?></td>	
	
	  
	</tr>

	<?PHP
}
}
?>
 </body>
                  </table>
                </div>
              </div>
            </div>
             </div>
                    </div>
                </div>
      
                </div>
                <script type="text/javascript">
         function rechercher(){
          var input = document.getElementById("rechercher").value ;
          window.location="afficherevente.php?search="+input;
         }
       </script>
                 
         <script src="./assets/js/plugins/jquery/dist/jquery.min.js"></script>
  <script src="./assets/js/plugins/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
  <!--   Optional JS   -->
  <script src="./assets/js/plugins/chart.js/dist/Chart.min.js"></script>
  <script src="./assets/js/plugins/chart.js/dist/Chart.extension.js"></script>
  <!--   Argon JS   -->
  <script src="./assets/js/argon-dashboard.min.js?v=1.1.2"></script>
  <script src="https://cdn.trackjs.com/agent/v3/latest/t.js"></script>
  <script>
    window.TrackJS &&
      TrackJS.install({
        token: "ee6fab19c5a04ac1a32a645abde4613a",
        application: "argon-dashboard-free"
      });
  </script>
</body>

</html>
 

