function verif_nom()
{
	var nom=document.getElementById("nom1").value;
	

	if(nom ==""){
	   document.getElementById("erreur_nom").innerHTML="verifier champs";
		
		return false;
	}
	else
	{   
      document.getElementById("erreur_nom").innerHTML="";


         return true;
	}
}
function verif_ref()
{
	var ref=document.getElementById("ref1").value;
	

	if(ref == 0){
	   document.getElementById("erreur_ref").innerHTML="verifier champs";
		
		return false;
	}
	else
	{   
      document.getElementById("erreur_ref").innerHTML="";


         return true;
	}
}
function verif_prix()
{
	var prix=document.getElementById("prix1").value;
	

	if(prix ==0){
	   document.getElementById("erreur_prix").innerHTML="verifier champs";
		
		return false;
	}
	else
	{   
      document.getElementById("erreur_prix").innerHTML="";


         return true;
	}
}
function verif_photo()
{
	var photo=document.getElementById("photo2").value;
	

	if(photo ==""){
	   document.getElementById("erreur_photo").innerHTML="verifier champs";
		
		return false;
	}
	else
	{   
      document.getElementById("erreur_photo").innerHTML="";


         return true;
	}

