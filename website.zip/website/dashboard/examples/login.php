<?php
session_start ();
include "user.php";
include "userC.php";
if(isset($_POST['sign'])){
$user= new user($_POST['idd'],'','',$_POST['pwd']);
$userC= new userC();
$res=$userC->login($user);
foreach($res as $row){
	$id=$row['id'];
	$pwd=$row['mot_de_passe'];
	$_SESSION['nom']=$row['nom'];
}if(($id==$_POST['idd']) && ($pwd==$_POST['pwd'])){
header('Location: ../index.html');

}

else {
	echo "<script>
alert('Mot de passe incorrecte ou id incorrecte');
window.location.href='login.html';
</script>";
}
}
?>