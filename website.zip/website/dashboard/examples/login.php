<?php
include "user.php";
include "userC.php";
if(isset($_POST['sign'])){
$user= new user($_POST['idd'],'','','',0,$_POST['pwd']);
$userC= new userC();
$res=$userC->login($user);
foreach($res as $row){
	$id=$row['id'];
	$pwd=$row['mdp'];
}
if(($id==$_POST['idd']) && ($pwd==$_POST['pwd'])){
header('Location: ../index.html');

}

else {
	echo "<script>
alert('MDP ou ID incorectte');
window.location.href='login.html';
</script>";
}
}
?>