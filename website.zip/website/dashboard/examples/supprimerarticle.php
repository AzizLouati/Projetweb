<?PHP
include "C:/wamp64/www/website/dashboard/article/Core/articlec.php";
$articleC=new articleC();
if (isset($_POST["ref"])){
	$articleC->supprimerarticle($_POST["ref"]);
	header('Location: afficher_liste_article.php');
}

?>