<?php
include "C:/wamp64/www/website/dashboard/article/Entities/article.php";
include "C:/wamp64/www/website/dashboard/article/Core/articlec.php";

if (isset($_POST['ref']) && isset($_POST['nom']) && isset($_POST['type'])&& isset($_POST['prix']) && isset($_POST['couleur_disponible']) && isset($_POST['photo']))
{ if (!empty($_POST['ref']) &&  !empty($_POST['nom'])&&  !empty($_POST['type']) &&  !empty($_POST['prix']) &&  !empty($_POST['couleur_disponible']) &&  !empty($_POST['photo']))
	{    
         $adresse=$_FILES['pic']['name'];  
         $ref= $_POST['ref'];
		 $nom= $_POST['nom'];
		 $type= $_POST['type'];
		 $prix= $_POST['prix'];
		 $couleur_disponible= $_POST['couleur_disponible'];
		 $photo= $_POST['photo'];
$e=new article ($ref,$nom,$type,$prix,$couleur_disponible,$photo);
$ec=new articlec();
$test= $ec->ajouter($e);
if($test==true)
{$uploads_dir = 'uploads';
	$target=basename($_FILES['pic']['name']);
	$tmp_name = $_FILES["pic"]["tmp_name"];
	//echo $_FILES['im']['size'];
	$ext=explode('.',$_FILES['pic']['name']);
	$extension=array('jpg','png','jpeg');
if(in_array(strtolower(end($ext)),$extension)){
	    $sql= "UPDATE  article set photo=:adresse where ref=:ref";
		$db = config::getConnexion();
		try{
        $req=$db->prepare($sql);
        $req->bindValue(':adresse',$adresse);
        $req->bindValue(':ref',$ref);
		$req->execute();
		}
		catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
        move_uploaded_file($tmp_name,"$uploads_dir/$target");

        }
	echo "<script>
alert('ajoutavec succes');
 window.location.href='../afficher_article.php';
</script>";
}	

}}
else
	echo "vérifier les champs";


?>