<?PHP
include "C:/wamp64/www/website/dashboard/article/Entities/article.php";
include "C:/wamp64/www/website/dashboard/article/Core/articlec.php";
$article=new article(01789,'robe',60,3,'a');
$articleeC=new articleC();
$articleeC->afficher_liste_article($article);
echo "****************";
echo "<br>";
echo "ref:".$article->getref();
echo "<br>";
echo "nom:".$article->getnom();
echo "<br>";
echo "prenom:".$article->getprix();
echo "<br>";
echo "nbH:".$article->getcouleur_disponible();
echo "<br>";
echo "tarif:".$article->getphoto();
echo "<br>";

?>