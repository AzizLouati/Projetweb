<?php
include "C:/wamp64/www/website/config.php";
class articlec
{
	public function ajouter($article)
	{
	$sql="insert into article (ref,nom,type,prix,couleur_disponible,photo)
	values (:ref,:nom,:type,:prix,:couleur_disponible,:photo)";
	$db=config::getConnexion();
	$req=$db->prepare($sql);
	try
	{
		$req->bindValue (':ref',$article->getref());  /*implementer les variables*/
		$req->bindValue (':nom',$article->getnom());
		$req->bindValue (':type',$article->get_type());
		$req->bindValue (':prix',$article->getprix());
		$req->bindValue (':couleur_disponible',$article->getcouleur_disponible());
		$req->bindValue (':photo',$article->getphoto());
		$req->execute();
		return true;
	}
	catch (Exception $e)
		{echo 'Erreur' .$e->getMessage();return false;}
	
    }
public function afficher ()
{   $sql="select * from article";    /*changement qq chose on utilise:prepare, bindvalue puis execution*/ /*query si pa de changement*/
    $db=config :: getConnexion();
try 
    {
	$liste=$db->query($sql);
	return $liste;
    }
    catch (Exception $e)
    {echo 'Echec' .$e->getMessage();}
}
function supprimerarticle($ref){
	$sql="DELETE FROM article WHERE ref= :ref ";
	$db =config::getConnexion();
	$req=$db->prepare($sql);
	$req->bindValue(':ref',$ref);
	try {
		  $req->execute();  //header('location: index.php');
	}
	catch (Exception $e) {
	die('erreur: '.$e->getMessage());
	}
}
/*-----------------------------------------------maintenant--------------------------------------------------------------------------*/

	function modifierarticle($article,$reff){
		$sql="UPDATE article SET ref=:reff, nom=:nom,type=:type,prix=:prix,couleur_disponible=:couleur_disponible WHERE ref=:ref";
		
		$db = config::getConnexion();
		//$db->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);
try{		
        $req=$db->prepare($sql);
		$ref=$article->getref();
        $nom=$article->getnom();
		$type=$article->get_type();
        $prix=$article->getprix();
        $couleur_disponible=$article->getcouleur_disponible();
        $photo=$article->getphoto();
		$req->bindValue(':reff',$ref);
		$req->bindValue(':ref',$reff);
		$req->bindValue(':nom',$nom);
	    $req->bindValue(':type',$type);
		$req->bindValue(':prix',$prix);
		$req->bindValue(':couleur_disponible',$couleur_disponible);
	
		
		
            $s=$req->execute();
			
           // header('Location: index.php');
        }
        catch (Exception $e){
            echo " Erreur ! ".$e->getMessage();

 
        }
		
	}
	function recupererarticle($ref){
		$sql="SELECT * from article where ref=$ref";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	
	function rechercherListearticle($nom){
		$sql="SELECT * from article where nom=$nom";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
}

		