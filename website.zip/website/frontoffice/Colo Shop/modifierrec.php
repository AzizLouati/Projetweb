<?php
session_start();
include "reclamation.php";
include "reclamationc.php";
$reclamationc=new reclamationc();
if (isset($_POST["update1"])){
	$edit=new reclamation($_SESSION['id'],$_POST['name'],$_POST['email'],$_POST['subject'],$_POST['message']);
	$reclamationc->modifierreclamation($edit,$_SESSION['id1']);

	echo "<script>
alert('Succes');
window.location.href='afficherrec.php';
</script>";
	}
	?>