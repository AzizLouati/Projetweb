<?php
include "C:/wamp64/www/website/config.php";
class ventec
{
	public function ajouter($vente)
	{
	$sql="insert into vente (ref,nom,type,prix,couleur_disponible,photo)
	values (:ref,:nom,:type,:prix,:couleur_disponible,:photo)";
	$db=config::getConnexion();
	$req=$db->prepare($sql);
	try
	{
		$req->bindValue (':ref',$vente->getref());  /*implementer les variables*/
		$req->bindValue (':nom',$vente->getnom());
		$req->bindValue (':type',$vente->get_type());
		$req->bindValue (':prix',$vente->getprix());
		$req->bindValue (':couleur_disponible',$vente->getcouleur_disponible());
		$req->bindValue (':photo',$vente->getphoto());
		$req->execute();
		return true;
	}
	catch (Exception $e)
		{echo 'Erreur' .$e->getMessage();return false;}
	
    }
public function afficher ()
{   $sql="select * from vente";    /*changement qq chose on utilise:prepare, bindvalue puis execution*/ /*query si pa de changement*/
    $db=config :: getConnexion();
try 
    {
	$liste=$db->query($sql);
	return $liste;
    }
    catch (Exception $e)
    {echo 'Echec' .$e->getMessage();}
}
function supprimerarticlev($ref){
	$sql="DELETE FROM vente WHERE ref= :ref ";
	$db =config::getConnexion();
	$req=$db->prepare($sql);
	$req->bindValue(':ref',$ref);
	try {
		  $req->execute();  //header('location: index.php');
	}
	catch (Exception $e) {
	die('erreur: '.$e->getMessage());
	}
}
/*-----------------------------------------------maintenant--------------------------------------------------------------------------*/

	function modifierarticlev($vente,$reff){
		$sql="UPDATE vente SET ref=:reff, nom=:nom, type=:type,prix=:prix,couleur_disponible=:couleur_disponible WHERE ref=:ref";
		
		$db = config::getConnexion();
		//$db->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);
try{		
        $req=$db->prepare($sql);
		$ref=$vente->getref();
        $nom=$vente->getnom();
		$type=$vente->get_type();
        $prix=$vente->getprix();
        $couleur_disponible=$vente->getcouleur_disponible();
        $photo=$vente->getphoto();
		$req->bindValue(':reff',$ref);
		$req->bindValue(':ref',$reff);
		$req->bindValue(':nom',$nom);
		$req->bindValue(':type',$type);
		$req->bindValue(':prix',$prix);
		$req->bindValue(':couleur_disponible',$couleur_disponible);
	
		
		
            $s=$req->execute();
			
           // header('Location: index.php');
        }
        catch (Exception $e){
            echo " Erreur ! ".$e->getMessage();

 
        }
		
	}
	function recupererarticle($ref){
		$sql="SELECT * from vente where ref=$ref";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	
	function rechercherListearticle($nom){
		$sql="SELECT * from vente where nom=$nom";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
}

		