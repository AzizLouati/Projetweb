<?PHP
include "C:/wamp64/www/website/frontoffice/Colo Shop/vente/Core/ventec.php";
$ventec=new ventec();
if (isset($_POST["ref"])){
	$venteC->supprimerarticle($_POST["ref"]);
	header('Location: afficher_liste_article.php');
}

?>