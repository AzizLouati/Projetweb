 <?php
 session_start();
 include "C:/wamp64/www/website/frontoffice/Colo Shop/vente/Core/ventec.php";
  include "C:/wamp64/www/website/frontoffice/Colo Shop/vente/Entities/vente.php";
  if (isset($_POST['mod'])){
	$ventec=new ventec();
	$vente=new vente($_POST['ref'],$_POST['nom'],$_POST['prix'],$_POST['couleur_disponible'],"");
	$ventec->modifierarticlev($vente,$_SESSION['refff']);
	echo "<script>
alert('Modification avec succes');
window.location.href='./afficher_articlev.php';
</script>";
  }
  ?>
  
	
	