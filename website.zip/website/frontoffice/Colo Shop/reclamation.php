<?PHP
class reclamation{
	private $idclient;
	private $nom;
	private $email;
	private $subject;
	private $message;
	function __construct($idclient,$nom,$email,$subject,$message){
		$this->idclient=$idclient;
		$this->nom=$nom;
		$this->email=$email;
		$this->subject=$subject;
		$this->message=$message;
	}
	function getidclient(){
		return $this->idclient;
	}
	function getnom(){
		return $this->nom;
	}
	function getemail(){
		return $this->email;
	}
	function getsubject(){
		return $this->subject;
	}
	function getmessage(){
		return $this->message;
	}
	function setnom($nom){
		$this->nom=$nom;
	}
	function setemail($email){
		$this->email=$email;
	}
	function setsubject($subject){
		$this->subject=$subject;
	}
	function setmessage($message){
		$this->message=$message;
	}
}
	?>