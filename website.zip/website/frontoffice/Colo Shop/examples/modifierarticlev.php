<HTML>
<head>
</head>
<body>
<?PHP
include "C:/wamp64/www/website/frontoffice/Colo Shop/vente/Entities/vente.php";
include "C:/wamp64/www/website/frontoffice/Colo Shop/vente/Core/ventec.php";
if (isset($_GET['ref'])){
	$ventec=new ventec();
    $result=$ventec->recupererarticle($_GET['ref']);
	foreach($result as $row){
		$ref=$row['ref'];
		$nom=$row['nom'];
		$prix=$row['prix'];
		$couleur_disponible=$row['couleur_disponible'];
		$photo=$row['photo'];
?>
<form method="POST">
<table>
<caption>modifier article</caption>
<tr>
<td>ref</td>
<td><input type="number" name="ref" value="<?PHP echo $ref ?>"></td>
</tr>
<tr>
<td>nom</td>
<td><input type="text" name="nom" value="<?PHP echo $nom ?>"></td>
</tr>
<tr>
<td>prix</td>
<td><input type="number" name="prix" value="<?PHP echo $prix ?>"></td>
</tr>
<tr>
<td>couleur_disponible</td>
<td><input type="number" name="couleur_disponible" value="<?PHP echo $couleur_disponible ?>"></td>
</tr>
<tr>
<td>photo</td>
<td><input type="text" name="photo" value="<?PHP echo $photo ?>"></td>
</tr>
<tr>
<td></td>
<td><input type="submit" name="modifier" value="modifier"></td>
</tr>
<tr>
<td></td>
<td><input type="hidden" name="ref_ini" value="<?PHP echo $_GET['ref'];?>"></td>
</tr>
</table>
</form>
<?PHP
	}
}
if (isset($_POST['modifier'])){
	$vente=new vente($_POST['ref'],$_POST['nom'],$_POST['prix'],$_POST['couleur_disponible'],$_POST['photo']);
	$ventec->modifierarticle($vente,$_POST['ref_ini']);
	echo $_POST['ref_ini'];
	header('Location: afficher_liste_article.php');
}
?>
</body>
</HTMl>