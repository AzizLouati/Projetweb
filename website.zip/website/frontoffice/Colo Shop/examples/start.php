<?PHP
include "C:/wamp64/www/website/frontoffice/Colo Shop/vente/Entities/vente.php";
include "C:/wamp64/www/website/frontoffice/Colo Shop/vente/Core/ventec.php";
$vente=new vente(01789,'robe',60,3,'a');
$venteeC=new ventec();
$venteeC->afficher_liste_articlev($);
echo "****************";
echo "<br>";
echo "ref:".$vente->getref();
echo "<br>";
echo "nom:".$vente->getnom();
echo "<br>";
echo "prenom:".$vente->getprix();
echo "<br>";
echo "nbH:".$vente->getcouleur_disponible();
echo "<br>";
echo "tarif:".$vente->getphoto();
echo "<br>";

?>