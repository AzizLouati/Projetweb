 <?php
 include "C:/wamp64/www/website/frontoffice/Colo Shop/vente/Core/ventec.php";
$vente1c=new ventec();
$liste_article=$vente1c->afficher_liste_articlev();

//var_dump($listearticles->fetchAll());
?>
<table border="1">
<tr>
<td>ref</td>
<td>nom</td>
<td>prix</td>
<td>couleur_disponible</td>
<td>photo</td>
<td>supprimer</td>
<td>modifier</td>
</tr>

<?PHP
foreach($listearticle as $row){
	?>
	<tr>
	<td><?PHP echo $row['ref']; ?></td>
	<td><?PHP echo $row['nom']; ?></td>
	<td><?PHP echo $row['prix']; ?></td>
	<td><?PHP echo $row['couleur_disponible']; ?></td>
	<td><?PHP echo $row['photo']; ?></td>
	<td><form method="POST" action="supprimerarticlev.php">
	<input type="submit" name="supprimer" value="supprimer">
	<input type="hidden" value="<?PHP echo $row['ref']; ?>" name="ref">
	</form>
	</td>
	<td><a href="modifierarticlev.php?ref=<?PHP echo $row['ref']; ?>">
	Modifier</a></td>
	</tr>
	<?PHP
}
?>
</table>