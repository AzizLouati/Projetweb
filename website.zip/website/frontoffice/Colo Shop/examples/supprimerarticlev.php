<?PHP
include "C:/wamp64/www/website/frontoffice/Colo Shop/vente/Core/ventec.php";
$ventec=new ventec();
if (isset($_POST["ref"])){
	$ventec->supprimerarticle($_POST["ref"]);
	header('Location: afficher_liste_articlev.php');
}

?>