<?php
include "C:/wamp64/www/website/frontoffice/Colo Shop/vente/Entities/vente.php";
include "C:/wamp64/www/website/frontoffice/Colo Shop/vente/Core/ventec.php";

if (isset($_POST['ref']) && isset($_POST['nom']) && isset($_POST['prix']) && isset($_POST['couleur_disponible']) && isset($_POST['photo']))
{ if (!empty($_POST['ref']) &&  !empty($_POST['nom']) &&  !empty($_POST['prix']) &&  !empty($_POST['couleur_disponible']) &&  !empty($_POST['photo']))
	{    
         $adresse=$_FILES['pic']['name'];  
         $ref= $_POST['ref'];
		 $nom= $_POST['nom'];
		 $prix= $_POST['prix'];
		 $couleur_disponible= $_POST['couleur_disponible'];
		 $photo= $_POST['photo'];
$e=new vente ($ref,$nom,$prix,$couleur_disponible,$photo);
$ec=new ventec();
$test= $ec->ajouter($e);
if($test==true)
{$uploads_dir = 'uploads';
	$target=basename($_FILES['pic']['name']);
	$tmp_name = $_FILES["pic"]["tmp_name"];
	//echo $_FILES['im']['size'];
	$ext=explode('.',$_FILES['pic']['name']);
	$extension=array('jpg','png','jpeg');
if(in_array(strtolower(end($ext)),$extension)){
	    $sql= "UPDATE  vente set photo=:adresse where ref=:ref";
		$db = config::getConnexion();
		try{
        $req=$db->prepare($sql);
        $req->bindValue(':adresse',$adresse);
        $req->bindValue(':ref',$ref);
		$req->execute();
		}
		catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
        move_uploaded_file($tmp_name,"$uploads_dir/$target");

        }
echo("ajout avec succes");
}	

}}
else
	echo "vérifier les champs";


?>