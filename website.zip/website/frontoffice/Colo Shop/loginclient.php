<?php
session_start();
include "client.php";
include "clientc.php";
if(isset($_POST['signin'])){
$client= new client($_POST['userid'],'',$_POST['pwd']);
$clientC= new clientC();
$res=$clientC->login($client);
foreach($res as $row){
	$id=$row['id'];
	$pwd=$row['pwd'];
	$_SESSION['nom']=$row['nom'];
	$_SESSION['id']=$row['id'];
}
if(($id==$_POST['userid']) && ($pwd==$_POST['pwd'])){
header('Location: afficherrec.php');

}

else {
	echo "<script>
alert('MDP ou ID incorectte');
window.location.href='loginclient.html';
</script>";
}
}
?>