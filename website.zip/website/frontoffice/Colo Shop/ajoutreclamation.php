<?PHP
session_start();
include "reclamation.php";
include "reclamationc.php";

if (isset($_POST['name']) and  isset($_POST['email']) and isset($_POST['subject']) and isset($_POST['message'])){
$reclamation1=new reclamation($_SESSION['id'],$_POST['name'],$_POST['email'],$_POST['subject'],$_POST['message']);

$reclamation1c=new reclamationc();
$reclamation1c->ajouterreclamation($reclamation1);

echo "<script>
alert('Succes');
window.location.href='afficherrec.php';
</script>";
	
}
//*/

?>