<?php
  session_start() ;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Profil</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="description" content="Colo Shop Template">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="styles/bootstrap4/bootstrap.min.css">
<link href="plugins/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/owl.carousel.css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/owl.theme.default.css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/animate.css">
<link rel="stylesheet" href="plugins/themify-icons/themify-icons.css">
<link rel="stylesheet" type="text/css" href="plugins/jquery-ui-1.12.1.custom/jquery-ui.css">
<link rel="stylesheet" type="text/css" href="styles/contact_styles.css">
<link rel="stylesheet" type="text/css" href="styles/contact_responsive.css">
</head>

<body>

<div class="super_container">

	<!-- Header -->
   <?php
       include 'header.php' ;
       include "../core/ClientC.php" ;

       if (isset($_SESSION["ID"])){
               $Cl = new ClientC() ;
                $result=$Cl->recupererClient($_SESSION["ID"]);
              foreach($result as $row){
                $id=$row['id'];
                $nom=$row['nom'];
                $prenom=$row['prenom'];
                $password=$row['password'];
                $email=$row['email'];
                $phone=$row['phone'] ;
                $address = $row['address'] ;

      }
     }

    ?>
				
	<!-- Slider -->

	<div class="main_slider" style="background-image:url(images/fond.jpg)">
		<div class="container fill_height">
			<div class="row align-items-center fill_height">
				<div class="col">
					<div class="main_slider_content">
				</div>
			</div>
		</div>
	</div>
	<!-- Hamburger Menu -->

		<div class="row">
			<div class="col">

				<!-- Breadcrumbs -->

				<div class="breadcrumbs d-flex flex-row align-items-center">
					<ul>
						<li><a href="#">Home</a></li>
						<li class="active"><a href="#"><i class="fa fa-angle-right" aria-hidden="true"></i>Contact</a></li>
					</ul>
				</div>

			</div>
		</div>

		<!-- Map Container -->

		<!-- Contact Us -->

		<div class="row" style="margin: auto;width: 80%;margin-top: 75px;">

			<div class="col-lg-6 contact_col">
				<div class="contact_contents">
					<h1 style="color: #dc3545">Mon Compte</h1>
					<p> </p>
				
					<div>
						<p style="color:#868e96"><i class="fa fa-user" aria-hidden="true"></i><a href=""> Profil</a></p>
					</div>
					<div>

						<p style="color:#868e96"><i class="fa fa-trash-o m-r-5"></i><a href="deleteAccount.php">  Supprimer</a></p>
					</div>
					<div>
						<p style="color:#868e96"><i class="fa fa-list"></i><a href="">Mes commandes</a></p>
					</div>
				</div>
			
				<!-- Follow Us -->

			</div>

			<div class="col-lg-6 get_in_touch_col">
				<div class="get_in_touch_contents">
					<center><h1 style="color: #dc3545">Informations </h1></center>
					<p id="Error"  style="color: #dc3545"></p>	
					<form method="POST" action="userEdit.php">
						<div>
							<input id="input_name" class="form_input input_name input_ph" type="text" name="nom" value="<?php echo $nom ;?>" required="required" data-error="Name is required." >
							<input id="input_prenom" class="form_input input_email input_ph" type="text" name="prenom" value="<?php echo $prenom ;?>" required="required" data-error="fisrt name is required.">
							<input id="input_email" class="form_input input_email input_ph" type="email" name="email" value="<?php echo $email ;?>" required="required" data-error="email is required." >
							<input id="input_password" class="form_input input_password input_ph" type="text" name="password" value="<?php echo $password ;?>" required="required" data-error="password is required." >
							<input id="input_phone" class="form_input input_phone input_ph" type="number" name="phone" value="<?php echo $phone ;?>" required="required" data-error="phone number is required.">
							<input id="input_address" class="form_input input_address input_ph" type="text" name="address" value="<?php echo $address ;?>" required="required" data-error="address is required.">
						</div>
						<div>
							<input type="hidden" name="idd" value="<?php echo $id ;?>">
							<center><button id="review_submit" type="submit" class="red_button message_submit_btn trans_300" value="Submit">Enregister</button></center>
						</div>
					</form>
				</div>
			</div>

		</div>
	

	<!-- Newsletter -->

	<div class="newsletter">
		<div class="container">
			<div class="row">
				<div class="col-lg-6">
					<div class="newsletter_text d-flex flex-column justify-content-center align-items-lg-start align-items-md-center text-center">
						<h4>Newsletter</h4>
						<p>Subscribe to our newsletter and get 20% off your first purchase</p>
					</div>
				</div>
				<div class="col-lg-6">
					<form action="post">
						<div class="newsletter_form d-flex flex-md-row flex-column flex-xs-column align-items-center justify-content-lg-end justify-content-center">
							<input id="newsletter_email" type="email" placeholder="Your email" required="required" data-error="Valid email is required.">
							<button id="newsletter_submit" type="submit" class="newsletter_submit_btn trans_300" value="Submit">subscribe</button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>

	<!-- Footer -->

	<footer class="footer">
		<div class="container">
			<div class="row">
				<div class="col-lg-6">
					<div class="footer_nav_container d-flex flex-sm-row flex-column align-items-center justify-content-lg-start justify-content-center text-center">
						<ul class="footer_nav">
							<li><a href="#">Blog</a></li>
							<li><a href="#">FAQs</a></li>
							<li><a href="contact.html">Contact us</a></li>
						</ul>
					</div>
				</div>
				<div class="col-lg-6">
					<div class="footer_social d-flex flex-row align-items-center justify-content-lg-end justify-content-center">
						<ul>
							<li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
							<li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
							<li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
							<li><a href="#"><i class="fa fa-skype" aria-hidden="true"></i></a></li>
							<li><a href="#"><i class="fa fa-pinterest" aria-hidden="true"></i></a></li>
						</ul>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-lg-12">
					<div class="footer_nav_container">
						<div class="cr">©2018 All Rights Reserverd. Template by <a href="#">Colorlib</a></div>
					</div>
				</div>
			</div>
		</div>
	</footer>

</div>

<script src="js/jquery-3.2.1.min.js"></script>
<script src="styles/bootstrap4/popper.js"></script>
<script src="styles/bootstrap4/bootstrap.min.js"></script>
<script src="plugins/Isotope/isotope.pkgd.min.js"></script>
<script src="plugins/OwlCarousel2-2.2.1/owl.carousel.js"></script>
<script src="plugins/easing/easing.js"></script>
<script src="https://maps.googleapis.com/maps/api/js?v=3.exp&key=AIzaSyCIwF204lFZg1y4kPSIhKaHEXMLYxxuMhA"></script>
<script src="plugins/jquery-ui-1.12.1.custom/jquery-ui.js"></script>
<script src="js/contact_custom.js"></script>
</body>

</html>
