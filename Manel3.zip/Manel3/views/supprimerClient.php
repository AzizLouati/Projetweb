<?PHP
include "../core/clientC.php";
$clt=new ClientC();
if (isset($_GET["id"])){
	$clt->supprimerClient($_GET["id"]);
    echo "<script>
          alert('suppression avec Succes');
          window.location='listeClient.php';
          </script>";
	//header('Location: listeClient.php');
}

?>