<?php
// On dÃ©marre la session
session_start ();

// On dÃ©truit les variables de notre session
session_unset ();

// On dÃ©truit notre session
session_destroy ();

// On redirige le visiteur vers la page d'accueil
echo "<script>
          alert('Succes logout');
          window.location=' home.php';
          </script>";
//header ('location: home.php');
?>

