<?php
 session_start() ;

  include "../core/ClientC.php" ;
  include "../entities/Client.php" ;

  if(isset($_POST['idd']) && isset($_POST['nom']) && isset($_POST['prenom']) && isset($_POST['email']) && isset($_POST['password']) && isset($_POST['phone']) && isset($_POST['address']))
  {
        $clt=new Client($_POST['idd'],$_POST['nom'],$_POST['prenom'],$_POST['email'],$_POST['password'],$_POST['address'],$_POST['phone']);
        $cltC = new ClientC() ;
        $cltC->modifierClient($clt,$_POST['idd']);
        echo $_POST['idd'];
        //header('Location: afficherreclam.php');
        $_SESSION['nom'] = $_POST['nom'] ;
        $_SESSION['prenom'] = $_POST['prenom'];
        $_SESSION['login']=$_POST['email'];
        $_SESSION['password']=$_POST['password'];
       //echo "<script> window.location.reload(history.back());</script>";
        echo "<script>
          alert('Modification avec Succes');
          window.location='profil.php';
          </script>";
   
        //header('Location: profil.php');
 }
 else
  echo "undefined field";

?> 