<?php
session_start();
include "C:/wamp64/www/website/frontoffice/Colo Shop/entities/reclamation.php";
include "C:/wamp64/www/website/frontoffice/Colo Shop/core/reclamationc.php";
$reclamationc=new reclamationc();
if (isset($_POST["update1"])){
	$edit=new reclamation($_SESSION['id'],$_POST['name'],$_POST['email'],$_POST['subject'],$_POST['message']);
	$reclamationc->modifierreclamation($edit,$_SESSION['id1']);

	echo "<script>
alert('votre reclamation a ete mofifier avec sucess');
window.location.href='afficherrec.php';
</script>";
	}
	?>
	