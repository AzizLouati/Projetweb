<?PHP
session_start();
include "C:/wamp64/www/website/frontoffice/Colo Shop/entities/reclamation.php";
include "C:/wamp64/www/website/frontoffice/Colo Shop/core/reclamationc.php";

if (isset($_POST['name']) and  isset($_POST['email']) and isset($_POST['subject']) and isset($_POST['message'])){
$reclamation1=new reclamation($_SESSION['id'],$_POST['name'],$_POST['email'],$_POST['subject'],$_POST['message']);

$reclamation1c=new reclamationc();
$reclamation1c->ajouterreclamation($reclamation1);

echo "<script>
alert('ajout avec succes');
window.location.href='afficherrec.php';
</script>";
	
}
//*/

?>