function verifnom(){
	var nom=document.getElementById('input_name').value;
	if(nom==''){
		document.getElementById('erreur_nom').innerHTML="veuillez remplir ce champ";
	}
	else{
	document.getElementById('erreur_nom').innerHTML="";}
}
function verifcvc(){
	var cvc=document.getElementById('cvc').value;
	if(cvc==''){
		document.getElementById('erreur_cvc').innerHTML="veuillez remplir ce champ";
	}
}
function verifcard(){
	var card=document.getElementById('input_num').value;
	if(card.toString().length<=16){
		document.getElementById('erreur_card').innerHTML="veuillez remplir ce champ";
	}
}
function verifdate()
{
	var today2=new Date();
	var expiration=document.getElementById("input_date").value;
	var date_liv=new Date(expiration);
	if(date_liv<today2){
	document.getElementById('erreur_date').innerHTML="erreur la date doit etre superieur a la date acutelle";
	return false;}
	else return true;

}
