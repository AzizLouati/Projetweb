<?php

include "../../config.php";
class reclamationC {
	function ajouterreclamation($reclamation){
		$sql="insert into reclamation (idclient,nom,email,subject,message) values (:idclient,:nom,:email,:subject,:message)";
		$db = config::getConnexion();
		try{
        $req=$db->prepare($sql);
		$idclient=$reclamation->getidclient();
        $nom=$reclamation->getnom();
        $email=$reclamation->getemail();
        $subject=$reclamation->getsubject();
        $message=$reclamation->getmessage();
        $req->bindValue(':idclient',$idclient);
		$req->bindValue(':nom',$nom);
		$req->bindValue(':email',$email);
		$req->bindValue(':subject',$subject);
		$req->bindValue(':message',$message);
		
            $req->execute();
           
        }
        catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
       
		}
	
	function afficherreclamation($id){
		//$sql="SElECT * From employe e inner join formationphp.employe a on e.cin= a.cin";
		$sql="SElECT * From reclamation where idclient= $id";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }	
	}
	function supprimerreclamation($id){
		$sql="DELETE FROM reclamation where id= $id";
		$db = config::getConnexion();
        $req=$db->prepare($sql);
		$req->bindValue(':id',$id);
		try{
            $req->execute();
           // header('Location: index.php');
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	function modifierreclamation($reclamation,$id){
		$sql="UPDATE reclamation SET nom=:nom,email=:email,subject=:subject,message=:message WHERE id=:id";
		
		$db = config::getConnexion();
		//$db->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);
try{		
        $req=$db->prepare($sql);
        $nom=$reclamation->getnom();
        $email=$reclamation->getemail();
        $subject=$reclamation->getsubject();
        $message=$reclamation->getmessage();
		$req->bindValue(':id',$id);
		$req->bindValue(':nom',$nom);
		$req->bindValue(':email',$email);
		$req->bindValue(':subject',$subject);
		$req->bindValue(':message',$message);
		
		
            $s=$req->execute();
			
           // header('Location: index.php');
        }
        catch (Exception $e){
            echo " Erreur ! ".$e->getMessage();
  
        }
		
	}
	function recupererreclamation($id){
		$sql="SELECT * from reclamation where id=$id";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	function rechercherreclamation($subject){
		$sql="SELECT * from reclamation where subject=$subject";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	}
?>		