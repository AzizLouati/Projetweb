<?php
class client{
	private $id;
	private $nom;
	private $mdp;
	function __construct($id,$nom,$mdp){
		$this->id=$id;
		$this->nom=$nom;
		$this->mdp=$mdp;
	}
	function getid(){
		return $this->id;
	}
	
	function getnom(){
		return $this->nom;
	}
	
	function getmdp(){
		return $this->mdp;
	}

	function setnom($nom){
		$this->nom=$nom;
	}
	
	function setmdp($mdp){
		$this->mdp=$mdp;
	}
	
}


?>