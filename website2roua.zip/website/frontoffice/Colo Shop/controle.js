function verifnom(){
	var nom=document.getElementById('input_name').value;
	if(nom==''){
		document.getElementById('erreur_nom').innerHTML="veuillez remplir ce champ";
	}
}