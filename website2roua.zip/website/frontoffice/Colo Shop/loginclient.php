<?php
session_start();
include "C:/wamp64/www/website/frontoffice/Colo Shop/entities/client.php";
include "C:/wamp64/www/website/frontoffice/Colo Shop/core/clientc.php";
if(isset($_POST['signin'])){
$client= new client($_POST['userid'],'',$_POST['pwd']);
$clientC= new clientC();
$res=$clientC->login($client);
foreach($res as $row){
	$id=$row['id'];
	$pwd=$row['pwd'];
	$_SESSION['nom']=$row['nom'];
	
	$_SESSION['id']=$row['id'];
}
if(($id==$_POST['userid']) && ($pwd==$_POST['pwd'])){
header('Location: afficherrec.php');

}

else {
	echo "<script>
alert('login ou mot de passe est incorrect');
window.location.href='loginclient.html';
</script>";
}
}
?>