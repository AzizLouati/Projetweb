<?PHP
include "../entities/event.php";
include "../core/eventC.php";

if (isset($_POST['reference']) and isset($_POST['titre']) and isset($_POST['image'])and isset($_POST['datedebut']) and isset($_POST['datefin'])and isset($_POST['description']) ){
$event1=new event($_POST['reference'],$_POST['titre'],$_POST['image'],$_POST['datedebut'],$_POST['datefin'],$_POST['description']);
//Partie2
/*
var_dump($employe1);
}
*/
//Partie3
$event1C=new eventC();
$event1C->ajouterevent($event1);
//header('Location: afficherevent.php');
 echo "<script>
alert('ajout avec succes');
window.location.href='afficherevent.php';
window.location.href='afficherevente.php';
</script>";	
}else{
	echo "vérifier les champs";
}
//*/

?>