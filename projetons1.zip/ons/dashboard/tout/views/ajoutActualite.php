<?PHP
include "../entities/Actualite.php";
include "../core/ActualiteC.php";

if (isset($_POST['numActualite']) and isset($_POST['titre']) and isset($_POST['image'])and isset($_POST['date_actualite'])and isset($_POST['description']) ){
$Actualite1=new Actualite($_POST['numActualite'],$_POST['titre'],$_POST['image'],$_POST['date_actualite'],$_POST['description']);
//Partie2
/*
var_dump($employe1);
}
*/
//Partie3
$Actualite1C=new ActualiteC();
$Actualite1C->ajouterActualite($Actualite1);
//header('Location: afficherEmploye.php');
 echo "<script>
alert('ajout avec succes');
window.location.href='afficherActualite.php';
</script>";	
}else{
	echo "vérifier les champs";
}
//*/

?>