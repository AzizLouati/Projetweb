<?PHP
session_start();
include "../entities/paiement.php";
include "../core/paiementc.php";


if (isset($_POST['idclient']) && isset($_POST['num_cart']) && isset($_POST['date_cart']) && isset($_POST['cvc'])){
$paiement1=new paiement($_SESSION['idclient'],$_POST['num_cart'],$_POST['date_cart'],$_POST['cvc']);
$paiement1C=new paiementC();
$Actualite1C->ajoutercarte($Actualite1);
//header('Location: afficherEmploye.php');
  echo "<script>
alert('ajout avec succes');
window.location.href='affichepaiement.php';
</script>";
}else{
  echo "vérifier les champs";
}

     	
	
		
