<?PHP
include "C:/wamp6/www/Nouveau dossier (5)/dashboard/tout/config.php";

class eventC {
function afficherevent ($evenement){
		echo "refernce: ".$evenement->getReference()."<br>";
		echo "Titre: ".$evenement->getTitre()."<br>";
		echo "Image: ".$evenement->getImage()."<br>";
		echo "Description: ".$evenement->getDescription()."<br>";
		echo "Date_fin: ".$evenement->getDateevent()."<br>";
		echo "Date_debut: ".$evenement->getDateevente()."<br>";
		}
	function ajouterevent($evenement){
		$sql="insert into evenement (reference,titre,image,datedebut,datefin,description) values (:reference, :titre,:image,:datedebut,:datefin,:description)";
		$db = config::getConnexion();
		try{
        $req=$db->prepare($sql);
		
        $reference=$evenement->getReference();
        $titre=$evenement->getTitre();
            $image=$evenement->getImage();
            $datefin=$evenement->getDateevent();
              $datedebut=$evenement->getDateevente();
               $description=$evenement->getDescription();
		$req->bindValue(':reference',$reference);
		$req->bindValue(':titre',$titre);
		$req->bindValue(':image',$image);
		$req->bindValue(':datedebut',$datedebut);
	$req->bindValue(':datefin',$datefin);
		$req->bindValue(':description',$description);
            $req->execute();
           
        }
        catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
		
	}
	
	function afficherevents(){
		//$sql="SElECT * From employe e inner join formationphp.employe a on e.cin= a.cin";
		$sql="SElECT * From evenement";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }	
	}
	function supprimerevent($reference){
		$sql="DELETE FROM evenement where reference= :reference";
		$db = config::getConnexion();
        $req=$db->prepare($sql);
		$req->bindValue(':reference',$reference);
		try{
            $req->execute();
           // header('Location: index.php');
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	function modifierevent($evenement,$reference){
		$sql="UPDATE evenement SET reference=:referencee, titre=:titre, image=:image ,description=:description,datedebut=:datedebut,datefin=:datefin   WHERE reference=:reference";
		
		$db = config::getConnexion();
		//$db->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);
try{		
        $req=$db->prepare($sql);
		$referencee=$evenement->getReference();
        $titre=$evenement->getTitre();
        $image=$evenement->getImage();
           $datefin=$evenement->getDateevent();
              $datedebut=$evenement->getDateevente();
		$description=$evenement->getDescription();
		
		$datas = array(':referencee'=>$referencee, ':reference'=>$reference, 'titre'=>$titre ,'image'=>$image,'datefin'=>$datefin,'datedebut'=>$datedebut,'description'=>$description);
		$req->bindValue(':referencee',$referencee);
		$req->bindValue(':reference',$reference);
		$req->bindValue(':titre',$titre);
		$req->bindValue(':image',$image);
		$req->bindValue(':description',$description);
		$req->bindValue(':datefin',$datefin);
		$req->bindValue(':datedebut',$datedebut);
            $s=$req->execute();
			
           // header('Location: index.php');
        }
        catch (Exception $e){
            echo " Erreur ! ".$e->getMessage();
   echo " Les datas : " ;
  print_r($datas);
        }
		
	}
	function recupererevent($reference){
		$sql="SELECT * from evenement where reference=$reference";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	
	function rechercherListeevent($search){
		$sql="SELECT * from evenement where  `reference` LIKE '%$search%'  OR `titre`like '%$search%'  OR `datedebut`like '%$search%'";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}

	function afficherDESC()
     {
    $sql="select * from evenement ORDER BY reference DESC";
    $db = config::getConnexion();
    return ($db->query($sql));
    
     }

   function afficherASC()
   {
    $sql="select * from evenement ORDER BY reference ASC";
    $db = config::getConnexion();
    return ($db->query($sql));
    }

}

?>