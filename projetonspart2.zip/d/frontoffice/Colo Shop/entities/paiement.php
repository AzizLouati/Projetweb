<?php
class payement
{
	
	private $idclient;
	
	private $num_cart;
	private $date_cart;
	private $cvc;
	
	function __construct($idclient,$num_cart,$date_cart,$cvc)
	{
		$this->idclient=$idclient;
		
		
		$this->num_cart=$num_cart;
		$this->date_cart=$date_cart;
		$this->cvc=$cvc;
	}

	function getid()
	{
		return $this->idclient;	
	}


	
	

	



function getcvc()
	{
		return $this->cvc;	
	}

	
	function setid($idclient)
	{
		return $this->idclient=$idclient;	
	}


	function setnom($nom)
	{
		return $this->nom=$nom;	
	}

	function setemail($email)
	{
		return $this->email=$email;	
	}

	
	function getnum()
	{
		return $this->num_cart ;
	}

	function getDateC()
	{
		return $this->date_cart;	
	}



function setcvc($cvc)
	{
		return $this->cvc=$cvc;	
	}

	
	

	
}
?>