<?PHP
include "C:\wamp6\www\d\config.php";

class paiementC {
function affichercarte ($carte){
		echo "idclient: ".$carte->getid()."<br>";
	
		echo "num_cart: ".$carte->getnum()."<br>";
		echo "date_cart: ".$carte->getDateC()."<br>";
			echo "cvc: ".$carte->getcvc()."<br>";
		}
	function ajoutercarte($carte){
		$sql="insert into carte (idclient,num_cart,date_cart,cvc) values (:idclient,:num_cart,:date_cart,:cvc)";
		$db = config::getConnexion();
		try{
        $req=$db->prepare($sql);
		
        $idclient=$carte->getid();
       
            $num_cart=$carte->getnum();
            $date_cart=$carte->getDateC();
            $cvc=$carte->getcvc();
              
		$req->bindValue(':idclient',$idclient);
		
		$req->bindValue(':num_cart',$num_cart);
		$req->bindValue(':date_cart',$date_cart);
		$req->bindValue(':cvc',$cvc);

		
            $req->execute();
           
        }
        catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
		
	}
}


	
	?>