<?PHP
include "C:/wamp6/www/Nouveau dossier (5)/dashboard/tout/config.php";

class ActualiteC {
function afficherActualite ($actualite){
		echo "NumActualite: ".$actualite->getnumActualite()."<br>";
		echo "Titre: ".$actualite->gettitre()."<br>";
		echo "Image: ".$actualite->getimage()."<br>";
		echo "Description: ".$actualite->getDescription()."<br>";
		echo "Date: ".$actualite->getdate()."<br>";
		}
	function ajouterActualite($actualite){
		$sql="insert into actualite (numActualite,titre,image,date_actualite,description) values (:numActualite, :titre,:image,:date_actualite,:description)";
		$db = config::getConnexion();
		try{
        $req=$db->prepare($sql);
		
        $numActualite=$actualite->getnumActualite();
        $titre=$actualite->gettitre();
            $image=$actualite->getimage();
            $date_actualite=$actualite->getdate();
               $description=$actualite->getDescription();
		$req->bindValue(':numActualite',$numActualite);
		$req->bindValue(':titre',$titre);
		$req->bindValue(':image',$image);
		$req->bindValue(':date_actualite',$date_actualite);

		$req->bindValue(':description',$description);
            $req->execute();
           
        }
        catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
		
	}
	
	function afficherActualites(){
		//$sql="SElECT * From employe e inner join formationphp.employe a on e.cin= a.cin";
		$sql="SElECT * From actualite";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }	
	}
	function supprimerActualite($numActualite){
		$sql="DELETE FROM actualite where numActualite= :numActualite";
		$db = config::getConnexion();
        $req=$db->prepare($sql);
		$req->bindValue(':numActualite',$numActualite);
		try{
            $req->execute();
           // header('Location: index.php');
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	function modifierActualite($actualite,$numActualite){
		$sql="UPDATE actualite SET numActualite=:numActualitee, titre=:titre, image=:image ,description=:description,date_actualite=:date_actualite WHERE numActualite=:numActualite";
		
		$db = config::getConnexion();
		//$db->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);
try{		
        $req=$db->prepare($sql);
		$numActualitee=$actualite->getnumActualite();
        $titre=$actualite->gettitre();
        $image=$actualite->getimage();
          $date_actualite=$actualite->getdate();
		$req->bindValue(':description',$description);
			$req->bindValue(':date_actualite',$date_actualite);
		
		$datas = array(':numActualitee'=>$numActualitee, ':numActualite'=>$numActualite, 'titre'=>$titre ,'image'=>$image,'date_actualite'=>$date_actualite,'description'=>$description);
		$req->bindValue(':numActualitee',$numActualitee);
		$req->bindValue(':numActualite',$numActualite);
		$req->bindValue(':titre',$titre);
		$req->bindValue(':image',$image);
		$req->bindValue(':description',$description);
		$req->bindValue(':date_actualite',$date_actualite);
            $s=$req->execute();
			
           // header('Location: index.php');
        }
        catch (Exception $e){
            echo " Erreur ! ".$e->getMessage();
   echo " Les datas : " ;
  print_r($datas);
        }
		
	}
	function recupererActualite($numActualite){
		$sql="SELECT * from actualite where numActualite=$numActualite";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	
	function rechercherListeActualite($num){
		$sql="SELECT * from employe where numActualite=$num";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}

	function afficherDESC()
     {
    $sql="select * from actualite ORDER BY numActualite DESC";
    $db = config::getConnexion();
    return ($db->query($sql));
    
     }

   function afficherASC()
   {
    $sql="select * from actualite ORDER BY numActualite ASC";
    $db = config::getConnexion();
    return ($db->query($sql));
    }

}

?>