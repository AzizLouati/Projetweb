<?PHP
include "C:/wamp6/www/Nouveau dossier (5)/dashboard/tout/config.php";

class eventC {
function afficherevent ($actualite){
		echo "refernce: ".$actualite->getReference()."<br>";
		echo "Titre: ".$actualite->getTitre()."<br>";
		echo "Image: ".$actualite->getImage()."<br>";
		echo "Description: ".$actualite->getDescription()."<br>";
		echo "Date: ".$actualite->getDateevent()."<br>";
		}
	function ajouterevent($evenement){
		$sql="insert into evenement (reference,titre,image,dateevent,description) values (:reference, :titre,:image,:dateevent,:description)";
		$db = config::getConnexion();
		try{
        $req=$db->prepare($sql);
		
        $reference=$evenement->getReference();
        $titre=$evenement->getTitre();
            $image=$evenement->getImage();
            $dateevent=$evenement->getDateevent();
               $description=$evenement->getDescription();
		$req->bindValue(':reference',$reference);
		$req->bindValue(':titre',$titre);
		$req->bindValue(':image',$image);
		$req->bindValue(':dateevent',$dateevent);

		$req->bindValue(':description',$description);
            $req->execute();
           
        }
        catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
		
	}
	
	function afficherevents(){
		//$sql="SElECT * From employe e inner join formationphp.employe a on e.cin= a.cin";
		$sql="SElECT * From evenement";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }	
	}
	function supprimerevent($reference){
		$sql="DELETE FROM evenement where reference= :reference";
		$db = config::getConnexion();
        $req=$db->prepare($sql);
		$req->bindValue(':reference',$reference);
		try{
            $req->execute();
           // header('Location: index.php');
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	function modifierevent($evenement,$reference){
		$sql="UPDATE evenement SET reference=:referencee, titre=:titre, image=:image ,description=:description,dateevent=:dateevent WHERE reference=:reference";
		
		$db = config::getConnexion();
		//$db->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);
try{		
        $req=$db->prepare($sql);
		$referencee=$evenement->getReference();
        $titre=$evenement->getTitre();
        $image=$evenement->getImage();
          $dateevent=$evenement->getDateevent();
		$description=$evenement->getDescription();
		
		$datas = array(':referencee'=>$referencee, ':reference'=>$reference, 'titre'=>$titre ,'image'=>$image,'dateevent'=>$dateevent,'description'=>$description);
		$req->bindValue(':referencee',$referencee);
		$req->bindValue(':reference',$reference);
		$req->bindValue(':titre',$titre);
		$req->bindValue(':image',$image);
		$req->bindValue(':description',$description);
		$req->bindValue(':dateevent',$dateevent);
            $s=$req->execute();
			
           // header('Location: index.php');
        }
        catch (Exception $e){
            echo " Erreur ! ".$e->getMessage();
   echo " Les datas : " ;
  print_r($datas);
        }
		
	}
	function recupererevent($reference){
		$sql="SELECT * from evenement where reference=$reference";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	
	function rechercherListeevent($ref){
		$sql="SELECT * from evenement where reference=$ref";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}

	function afficherDESC()
     {
    $sql="select * from evenement ORDER BY reference DESC";
    $db = config::getConnexion();
    return ($db->query($sql));
    
     }

   function afficherASC()
   {
    $sql="select * from evenement ORDER BY reference ASC";
    $db = config::getConnexion();
    return ($db->query($sql));
    }

}

?>