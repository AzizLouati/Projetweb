<?PHP
session_start();
include "C:/wamp6/www/d/frontoffice/Colo Shop/entities/paiement.php";
include "C:/wamp6/www/d/frontoffice/Colo Shop/core/paiementC.php";


if (isset($_POST['idclient']) && isset($_POST['num_cart']) && isset($_POST['date_cart']) && isset($_POST['cvc'])){
$paiement1=new payement($_SESSION['ID'],$_POST['num_cart'],$_POST['date_cart'],$_POST['cvc']);
$paiement1C=new paiementC();
$paiement1C->ajoutercarte($paiement1);
//header('Location: afficherEmploye.php');
  echo "<script>
alert('ajout avec succes');
window.location.href='affichepaiement.php';
</script>";
}else{
  echo "vérifier les champs";
}

     	
	
		
