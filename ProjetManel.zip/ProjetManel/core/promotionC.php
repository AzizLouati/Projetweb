<?php 
  include "../config.php" ;

  class PromotionC 
  {
  	
    public function ajouterPromotion($promotion) 
   	{
   		$sql="insert into promotion(id_promo,dateDebut,dateFin,remise,ref) values(:id_promo,:dateDebut,:dateFin,:remise,:ref)" ; 
   		$db=config::getConnexion() ;
   		$req=$db->prepare($sql) ;
   		try 
   		{
   			$req->bindValue(':id_promo',$promotion->getIDPromo());
   			$req->bindValue(':remise',$promotion->getRemise());
   			$req->bindValue(':dateDebut',$promotion->getDateDebut());
   			$req->bindValue(':dateFin',$promotion->getDateFin());
   			$req->bindValue(':ref',$promotion->getref());
   			$req->execute() ;
   			return true ;

   		}
	   	 catch(Exception $e) 
	   	{
	   		echo "Erreur".$e->getMessage();
	   	}

   	}

   	public function afficherPromotion()
   	{
   		$sql="SELECT photo,nom,id_promo,article.ref as reff,remise,dateDebut,dateFin,prix FROM `promotion` INNER JOIN `article` on promotion.ref=article.ref " ; 
   		$db=config::getConnexion() ;
   		try
   		{
   			$liste=$db->query($sql) ;
   			return $liste ;

   		}
	   	 catch(Exception $e) 
	   	{
	   		echo "Erreur".$e->getMessage();
	   	}
   	}

   	public function supprimerPromo($id)
    {
       $sql="delete from promotion where id_promo = :id " ; 
         $db=config::getConnexion() ;
         $req=$db->prepare($sql) ;
         $req->bindValue(':id',$id);
         try
         {
            
            $req->execute() ;

         }
          catch(Exception $e) 
         {
            die("Erreur".$e->getMessage());
         }
    }

    function modifierPromotion($promotion,$id)
      {
      $sql="UPDATE `promotion` SET id_promo=:idd,remise=:remise,dateDebut=:dateDebut,dateFin=:dateFin,ref=:ref WHERE id_promo=:id";
      
       $db = config::getConnexion();
      //$db->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);
      try{     
              $req=$db->prepare($sql);
              $idd=$promotion->getIDPromo();
              $remise=$promotion->getRemise();
              $dateDebut=$promotion->getDateDebut();
              $dateFin=$promotion->getDateFin();
              $ref=$promotion->getref() ;
            $datas = array(':idd'=>$idd,
            				':id'=>$id, 
            				':ref'=>$ref, 
            				':remise'=>$remise,
            				':dateDebut'=>$dateDebut ,
            				':dateFin'=>$dateFin 
            			);
            $req->bindValue(':idd',$idd);
            $req->bindValue(':id',$id);
            $req->bindValue(':ref',$ref);
            $req->bindValue(':remise',$remise); 
            $req->bindValue(':dateDebut',$dateDebut);
            $req->bindValue(':dateFin',$dateFin);      
            
                  $s=$req->execute();
               
                 // header('Location: index.php');
                  }
        catch (Exception $e){
            echo " Erreur ! ".$e->getMessage();
            echo " Les datas : " ;
            print_r($datas);
        }
      
    }

     function recupererPromotion($id)
      {
         $sql="SELECT photo,nom,id_promo,article.ref as reff,remise,dateDebut,dateFin,prix FROM `promotion` INNER JOIN `article` on promotion.ref=article.ref where id_promo=$id";
         $db = config::getConnexion();
         try{
         $liste=$db->query($sql);
         return $liste;
         }
           catch (Exception $e){
               die('Erreur: '.$e->getMessage());
           }
      }

      function rechercherPromotion($search)
      {
         $sql="SELECT photo,nom,id_promo,ref,remise,dateDebut,dateFin FROM `promotion` INNER JOIN `article` on promotion.ref=article.ref where `id_promo` LIKE '%$search%'  OR `remise`like '%$search%' OR `dateDebut`like '%$search%' OR `dateFin`like '%$search%'  OR `ref`like '%$search%' OR `nom`like '%$search%' " ;
         $db = config::getConnexion();
         try{
         $liste=$db->query($sql);
         return $liste;
         }
           catch (Exception $e){
               die('Erreur: '.$e->getMessage());
           }
      }

      function recupererarticle($ref)
      {
         $sql="SELECT * from article where ref=$ref";
         $db = config::getConnexion();
         try{
         $liste=$db->query($sql);
         return $liste;
         }
           catch (Exception $e){
               die('Erreur: '.$e->getMessage());
           }
      }

      function setEtatPromo($state,$ref)
      {
         $sql="UPDATE `article` SET etatPromo=:etat WHERE ref=:ref";
      
          $db = config::getConnexion();
          try{
              $req=$db->prepare($sql); 
              $req->bindValue(':etat',$state);
              $req->bindValue(':ref',$ref) ;
              $s=$req->execute();
          }
        catch (Exception $e){
          echo " Erreur ! ".$e->getMessage();

      }
    }

  }

?>