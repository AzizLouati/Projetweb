<?php 
  include "../config.php" ;

  class PromotionAC 
  {
  	
    public function ajouterPromotionA($promotionA) 
   	{
   		$sql="insert into promotionA(id_promo,dateDebut,dateFin,remise,ref) values(:id_promo,:dateDebut,:dateFin,:remise,:ref)" ; 
   		$db=config::getConnexion() ;
   		$req=$db->prepare($sql) ;
   		try 
   		{
   			$req->bindValue(':id_promo',$promotionA->getIDPromo());
   			$req->bindValue(':remise',$promotionA->getRemise());
   			$req->bindValue(':dateDebut',$promotionA->getDateDebut());
   			$req->bindValue(':dateFin',$promotionA->getDateFin());
   			$req->bindValue(':ref',$promotionA->getref());
   			$req->execute() ;
   			return true ;

   		}
	   	 catch(Exception $e) 
	   	{
	   		echo "Erreur".$e->getMessage();
	   	}

   	}

   	public function afficherPromotionA()
   	{
   		$sql="SELECT photo,nom,id_promo,articleA.ref as reff,remise,dateDebut,dateFin,prix FROM `promotionA` INNER JOIN `articleA` on promotionA.ref=articleA.ref " ; 
   		$db=config::getConnexion() ;
   		try
   		{
   			$liste=$db->query($sql) ;
   			return $liste ;

   		}
	   	 catch(Exception $e) 
	   	{
	   		echo "Erreur".$e->getMessage();
	   	}
   	}

   	public function supprimerPromoA($id)
    {
       $sql="delete from promotionA where id_promo = :id " ; 
         $db=config::getConnexion() ;
         $req=$db->prepare($sql) ;
         $req->bindValue(':id',$id);
         try
         {
            
            $req->execute() ;

         }
          catch(Exception $e) 
         {
            die("Erreur".$e->getMessage());
         }
    }

    function modifierPromotionA($promotionA,$id)
      {
      $sql="UPDATE `promotionA` SET id_promo=:idd,remise=:remise,dateDebut=:dateDebut,dateFin=:dateFin,ref=:ref WHERE id_promo=:id";
      
       $db = config::getConnexion();
      //$db->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);
      try{     
              $req=$db->prepare($sql);
              $idd=$promotionA->getIDPromo();
              $remise=$promotionA->getRemise();
              $dateDebut=$promotionA->getDateDebut();
              $dateFin=$promotionA->getDateFin();
              $ref=$promotionA->getref() ;
            $datas = array(':idd'=>$idd,
            				':id'=>$id, 
            				':ref'=>$ref, 
            				':remise'=>$remise,
            				':dateDebut'=>$dateDebut ,
            				':dateFin'=>$dateFin 
            			);
            $req->bindValue(':idd',$idd);
            $req->bindValue(':id',$id);
            $req->bindValue(':ref',$ref);
            $req->bindValue(':remise',$remise); 
            $req->bindValue(':dateDebut',$dateDebut);
            $req->bindValue(':dateFin',$dateFin);      
            
                  $s=$req->execute();
               
                 // header('Location: index.php');
                  }
        catch (Exception $e){
            echo " Erreur ! ".$e->getMessage();
            echo " Les datas : " ;
            print_r($datas);
        }
      
    }

     function recupererPromotionA($id)
      {
         $sql="SELECT photo,nom,id_promo,articleA.ref as reff,remise,dateDebut,dateFin,prix FROM `promotionA` INNER JOIN `articleA` on promotionA.ref=articleA.ref where id_promo=$id";
         $db = config::getConnexion();
         try{
         $liste=$db->query($sql);
         return $liste;
         }
           catch (Exception $e){
               die('Erreur: '.$e->getMessage());
           }
      }

      function rechercherPromotionA($search)
      {
         $sql="SELECT photo,nom,id_promo,articleA.ref as reff,remise,dateDebut,dateFin,prix FROM `promotionA` INNER JOIN `articleA` on promotionA.ref=articleA.ref where `id_promo` LIKE '%$search%'  OR `remise`like '%$search%' OR `dateDebut`like '%$search%' OR `dateFin`like '%$search%'  OR articleA.ref like '%$search%' OR `nom`like '%$search%' " ;
         $db = config::getConnexion();
         try{
         $liste=$db->query($sql);
         return $liste;
         }
           catch (Exception $e){
               die('Erreur: '.$e->getMessage());
           }
      }

      function recupererarticleA($ref)
      {
         $sql="SELECT * from articleA where ref=$ref";
         $db = config::getConnexion();
         try{
         $liste=$db->query($sql);
         return $liste;
         }
           catch (Exception $e){
               die('Erreur: '.$e->getMessage());
           }
      }

      function setEtatPromoA($state,$ref)
      {
         $sql="UPDATE `articleA` SET etatPromoA=:etat WHERE ref=:ref";
      
          $db = config::getConnexion();
          try{
              $req=$db->prepare($sql); 
              $req->bindValue(':etat',$state);
              $req->bindValue(':ref',$ref) ;
              $s=$req->execute();
          }
        catch (Exception $e){
          echo " Erreur ! ".$e->getMessage();

      }
    }


    public function TrierpromotionA($colonne,$order)
    {
      $sql="SELECT photo,nom,id_promo,articleA.ref as reff,remise,dateDebut,dateFin,prix FROM `promotionA` INNER JOIN `articleA` on promotionA.ref=articleA.ref order by `$colonne` $order" ; 
      $db=config::getConnexion() ;
      try
      {
        $liste=$db->query($sql) ;
        return $liste ;

      }
       catch(Exception $e) 
      {
        echo "Erreur".$e->getMessage();
      }
    }

   public function getAllrowsEtat($state)
    {
       $sql="SELECT * from `articleA` WHERE etatPromoA=$state ";
         $db = config::getConnexion();
         try{
         $liste=$db->query($sql);
         return $liste->rowCount() ;
         }
           catch (Exception $e){
               die('Erreur: '.$e->getMessage());
           }

    }

  }

?>