<?php
  
   include "../config.php" ;
 
   class articleAC 
   {
    
    public function ajouterarticleA($articleA) 
    {
      $sql="insert into articleA(ref,nom,categorie,prix,size,color,photo) values(:ref,:nom,:categorie,:prix,:size,:color,:photo)" ;
      $db=config::getConnexion() ;
      $req=$db->prepare($sql) ;
      try
      {
        $req->bindValue(':ref',$articleA->getref());
        $req->bindValue(':nom',$articleA->getnom());        /*implementer les variables*/
        $req->bindValue(':categorie',$articleA->getcategorie());
        $req->bindValue(':prix',$articleA->getprix());
        $req->bindValue(':size',$articleA->getsize());
        $req->bindValue(':color',$articleA->getcolor());
        $req->bindValue(':photo',$articleA->getphoto());
        $req->execute() ;
        return true ;

      }
       catch(Exception $e) 
      {
        echo "Erreur".$e->getMessage();
      }

    }

    public function afficherarticleA()
    {
      $sql="select * from articleA" ;
      $db=config::getConnexion() ;
      try
      {
        $liste=$db->query($sql) ;
        return $liste ;

      }
       catch(Exception $e) 
      {
        echo "Erreur".$e->getMessage();
      }
    }

    public function supprimerarticleA($ref)
    {
       $sql="delete from articleA where ref = :ref " ;
         $db=config::getConnexion() ;
         $req=$db->prepare($sql) ;
         $req->bindValue(':ref',$ref);
         try
         {
            
            $req->execute() ;

         }
          catch(Exception $e) 
         {
            die("Erreur".$e->getMessage());
         }
    }

      function recupererarticleA($ref)
      {
         $sql="SELECT * from articleA where ref=$ref";
         $db = config::getConnexion();
         try{
         $liste=$db->query($sql);
         return $liste;
         }
           catch (Exception $e){
               die('Erreur: '.$e->getMessage());
           }
      }

      function modifierarticleA($articleA,$ref)
      {
      $sql="UPDATE articleA SET ref=:refd, nom=:nom,categorie=:categorie,size=:size,prix=:prix,color=:color,photo=:photo WHERE ref=:ref";
      
       $db = config::getConnexion();
      //$db->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);
      try{     
              $req=$db->prepare($sql);
              $refd=$articleA->getref();
              $nom=$articleA->getnom();
              $categorie=$articleA->getcategorie();
              $size=$articleA->getsize();
              $prix=$articleA->getprix();
              $color=$articleA->getcolor();
              $photo=$articleA->getphoto() ;
            $datas = array(':refd'=>$refd,':ref'=>$ref, ':nom'=>$nom, ':categorie'=>$categorie,':size'=>$size,':prix'=>$prix,':color'=>$color,':photo'=>$photo);
            $req->bindValue(':refd',$refd);
            $req->bindValue(':ref',$ref);
            $req->bindValue(':nom',$nom);
            $req->bindValue(':categorie',$categorie);
            $req->bindValue(':size',$size);
            $req->bindValue(':prix',$prix); 
            $req->bindValue(':color',$color);
            $req->bindValue(':photo',$photo);          
            
                  $s=$req->execute();
               
                 // header('Location: index.php');
                  }
        catch (Exception $e){
            echo " Erreur ! ".$e->getMessage();
            echo " Les datas : " ;
            print_r($datas);
        }
      
    }

    function rechercherarticleA($search)
      {
         $sql="SELECT * FROM `articleA` where `ref` LIKE '%$search%'  OR `nom` like '%$search%' OR `categorie` like '%$search%'  OR `size` like '%$search%' OR `prix` like '%$search%' OR `color` like '%$search%' OR `photo` like '%$search%'   " ;
         $db = config::getConnexion();
         try{
         $liste=$db->query($sql);
         return $liste;
         }
           catch (Exception $e){
               die('Erreur: '.$e->getMessage());
           }
      }

    public function TrierarticleA($colonne,$order)
    {
      $sql="select * from `articleA` order by `$colonne` $order" ; 
      $db=config::getConnexion() ;
      try
      {
        $liste=$db->query($sql) ;
        return $liste ;

      }
       catch(Exception $e) 
      {
        echo "Erreur".$e->getMessage();
      }
    }

    function recupererArticleAPromoA($ref)
    {
        $sql="SELECT * from `promotionA` where ref=$ref";
         $db = config::getConnexion();
         try{
         $liste=$db->query($sql);
         return $liste;
         }
           catch (Exception $e){
               die('Erreur: '.$e->getMessage());
           }

    }


   }

?>