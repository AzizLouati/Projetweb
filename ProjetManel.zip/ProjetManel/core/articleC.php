<?php
  
   include "../config.php" ;
 
   class articleC 
   {
    
    public function ajouterarticle($article) 
    {
      $sql="insert into article(ref,nom,categorie,prix,size,color,photo) values(:ref,:nom,:categorie,:prix,:size,:color,:photo)" ;
      $db=config::getConnexion() ;
      $req=$db->prepare($sql) ;
      try
      {
        $req->bindValue(':ref',$article->getref());
        $req->bindValue(':nom',$article->getnom());        /*implementer les variables*/
        $req->bindValue(':categorie',$article->getcategorie());
        $req->bindValue(':prix',$article->getprix());
        $req->bindValue(':size',$article->getsize());
        $req->bindValue(':color',$article->getcolor());
        $req->bindValue(':photo',$article->getphoto());
        $req->execute() ;
        return true ;

      }
       catch(Exception $e) 
      {
        echo "Erreur".$e->getMessage();
      }

    }

    public function afficherarticle()
    {
      $sql="select * from article" ;
      $db=config::getConnexion() ;
      try
      {
        $liste=$db->query($sql) ;
        return $liste ;

      }
       catch(Exception $e) 
      {
        echo "Erreur".$e->getMessage();
      }
    }

    public function supprimerarticle($ref)
    {
       $sql="delete from article where ref = :ref " ;
         $db=config::getConnexion() ;
         $req=$db->prepare($sql) ;
         $req->bindValue(':ref',$ref);
         try
         {
            
            $req->execute() ;

         }
          catch(Exception $e) 
         {
            die("Erreur".$e->getMessage());
         }
    }

      function recupererarticle($ref)
      {
         $sql="SELECT * from article where ref=$ref";
         $db = config::getConnexion();
         try{
         $liste=$db->query($sql);
         return $liste;
         }
           catch (Exception $e){
               die('Erreur: '.$e->getMessage());
           }
      }

      function modifierarticle($article,$ref)
      {
      $sql="UPDATE article SET ref=:refd, nom=:nom,categorie=:categorie,size=:size,prix=:prix,color=:color,photo=:photo WHERE ref=:ref";
      
       $db = config::getConnexion();
      //$db->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);
      try{     
              $req=$db->prepare($sql);
              $refd=$article->getref();
              $nom=$article->getnom();
              $categorie=$article->getcategorie();
              $size=$article->getsize();
              $prix=$article->getprix();
              $color=$article->getcolor();
              $photo=$article->getphoto() ;
            $datas = array(':refd'=>$refd,':ref'=>$ref, ':nom'=>$nom, ':categorie'=>$categorie,':size'=>$size,':prix'=>$prix,':color'=>$color,':photo'=>$photo);
            $req->bindValue(':refd',$refd);
            $req->bindValue(':ref',$ref);
            $req->bindValue(':nom',$nom);
            $req->bindValue(':categorie',$categorie);
            $req->bindValue(':size',$size);
            $req->bindValue(':prix',$prix); 
            $req->bindValue(':color',$color);
            $req->bindValue(':photo',$photo);          
            
                  $s=$req->execute();
               
                 // header('Location: index.php');
                  }
        catch (Exception $e){
            echo " Erreur ! ".$e->getMessage();
            echo " Les datas : " ;
            print_r($datas);
        }
      
    }

    function rechercherarticle($search)
      {
         $sql="SELECT * FROM `article` where `ref` LIKE '%$search%'  OR `nom` like '%$search%' OR `categorie` like '%$search%'  OR `size` like '%$search%' OR `prix` like '%$search%' OR `color` like '%$search%' OR `photo` like '%$search%'   " ;
         $db = config::getConnexion();
         try{
         $liste=$db->query($sql);
         return $liste;
         }
           catch (Exception $e){
               die('Erreur: '.$e->getMessage());
           }
      }

    public function Trierarticle($colonne,$order)
    {
      $sql="select * from `article` order by `$colonne` $order" ; 
      $db=config::getConnexion() ;
      try
      {
        $liste=$db->query($sql) ;
        return $liste ;

      }
       catch(Exception $e) 
      {
        echo "Erreur".$e->getMessage();
      }
    }

    function recupererArticlePromo($ref)
    {
        $sql="SELECT * from `promotion` where ref=$ref";
         $db = config::getConnexion();
         try{
         $liste=$db->query($sql);
         return $liste;
         }
           catch (Exception $e){
               die('Erreur: '.$e->getMessage());
           }

    }
  public function afficherarticleA()
      {
        $sql="select * from articleA" ;
        $db=config::getConnexion() ;
        try
        {
          $liste=$db->query($sql) ;
          return $liste ;

        }
         catch(Exception $e) 
        {
          echo "Erreur".$e->getMessage();
        }
      }

      function recupererArticleAPromoA($ref)
    {
        $sql="SELECT * from `promotionA` where ref=$ref";
         $db = config::getConnexion();
         try{
         $liste=$db->query($sql);
         return $liste;
         }
           catch (Exception $e){
               die('Erreur: '.$e->getMessage());
           }
     }
   }

?>



