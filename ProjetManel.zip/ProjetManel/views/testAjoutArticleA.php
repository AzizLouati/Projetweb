 <?php

     include '../core/articleAC.php';
     include '../entities/articleA.php';
     if(isset($_POST['ref']) && isset($_POST['nom']) && isset($_POST['categorie']) && isset($_POST['prix']) && isset($_POST['size']) && isset($_POST['color']) && isset($_POST['photo']))
        {
          if(!empty($_POST['ref']) && !empty($_POST['nom']) && !empty($_POST['categorie']) && !empty($_POST['prix']) && !empty($_POST['size']) && !empty($_POST['color']) && !empty($_POST['photo']) )
          {
             $adresse=$_FILES['pic']['name'];  
             $ref=$_POST['ref'] ;
             $nom=$_POST['nom'] ;
             $categorie=$_POST['categorie'] ;
             $prix=$_POST['prix'] ;
             $size=$_POST['size'] ;
             $color=$_POST['color'] ;
             $photo=$_POST['photo'] ;
             $art=new articleA($ref,$nom,$categorie,$prix,$size,$color,$photo);   
             $artC=new articleAC() ;
             $test=$artC->ajouterarticleA($art) ;
             if($test==true)
             {
               $uploads_dir = 'uploads';
               $target=basename($_FILES['pic']['name']);
               $tmp_name = $_FILES["pic"]["tmp_name"];
               //echo $_FILES['im']['size'];
               $ext=explode('.',$_FILES['pic']['name']);
               $extension=array('jpg','png','jpeg');
             if(in_array(strtolower(end($ext)),$extension)){
                $sql= "UPDATE  articleA set photo=:adresse where ref=:ref";
                $db = config::getConnexion();
                try{
                $req=$db->prepare($sql);
                $req->bindValue(':adresse',$adresse);
                $req->bindValue(':ref',$ref);
                $req->execute();
                }
                catch (Exception $e){
                    echo 'Erreur: '.$e->getMessage();
                }
                move_uploaded_file($tmp_name,"$uploads_dir/$target");


                    echo "<script>
                    alert('Ajouter articleA avec Succes');
                    window.location.href='afficher_articleA.php';
                    </script>";
                //header('Location: listearticleA.php');
             }

             else{
              echo "Echec";
            }
           }else { echo "champ vide";}

        }else { echo "champ manquant";}
         }
?>