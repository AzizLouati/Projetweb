 <?php

     include '../core/promotionC.php';
     include '../entities/promotion.php';
     if(isset($_POST['idPromo'])  && isset($_POST['dateFin']) && isset($_POST['dateDebut']) && isset($_POST['remise']) && isset($_POST['ref'])  )
        {
          if(!empty($_POST['idPromo']) && !empty($_POST['dateDebut']) && !empty($_POST['dateFin']) && !empty($_POST['remise'])  && !empty($_POST['ref']) )
          {
             $idpromo=$_POST['idPromo'] ;
             $ref=$_POST['ref'] ;
             $remise=$_POST['remise'] ;
             $dateDebut=$_POST['dateDebut'] ;
             $dateFin=$_POST['dateFin'] ;
             $promo=new Promotion($idpromo,$ref,$dateDebut,$dateFin,$remise);   
             $promoC=new PromotionC() ;
             $test=$promoC->ajouterPromotion($promo) ;
             $state = 1 ;
             $promoC->setEtatPromo($state,$ref) ;
             if($test==true)
             {
                echo "<script>
                  alert('ajout promo avec Succes');
                  window.location='listePromo.php';
                  </script>";
                //header('Location: listePromo.php');
             }

             else{
              echo "Echec";
            }
           }else { echo "champ vide";}

        }else { echo "champ manquant";}
?>