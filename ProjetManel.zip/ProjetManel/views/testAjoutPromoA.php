 <?php

     include '../core/promotionAC.php';
     include '../entities/promotionA.php';
     if(isset($_POST['idPromo'])  && isset($_POST['dateFin']) && isset($_POST['dateDebut']) && isset($_POST['remise']) && isset($_POST['ref'])  )
        {
          if(!empty($_POST['idPromo']) && !empty($_POST['dateDebut']) && !empty($_POST['dateFin']) && !empty($_POST['remise'])  && !empty($_POST['ref']) )
          {
             $idpromo=$_POST['idPromo'] ;
             $ref=$_POST['ref'] ;
             $remise=$_POST['remise'] ;
             $dateDebut=$_POST['dateDebut'] ;
             $dateFin=$_POST['dateFin'] ;
             $promoA=new PromotionA($idpromo,$ref,$dateDebut,$dateFin,$remise);   
             $promoAC=new PromotionAC() ;
             $test=$promoAC->ajouterPromotionA($promoA) ;
             $state = 1 ;
             $promoAC->setEtatPromoA($state,$ref) ;
             if($test==true)
             {
                echo "<script>
                  alert('Ajout promotionA avec Succes');
                  window.location='listePromoA.php';
                  </script>";
                //header('Location: listePromoA.php');
             }

             else{
              echo "Echec";
            }
           }else { echo "champ vide";}

        }else { echo "champ manquant";}
?>