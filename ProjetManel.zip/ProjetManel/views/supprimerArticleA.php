<?PHP
include "../core/articleAC.php";
$art=new articleAC();
if (isset($_POST["reff"]))
{
	$art->supprimerarticleA($_POST["reff"]);
    echo "<script>
          alert('Suppression avec Succes');
          window.location='afficher_articleA.php';
          </script>";
	//header('Location: listeArticleA.php');
}

?>
