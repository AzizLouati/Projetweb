<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>
    Ajouter Article
  </title>
  <!-- Favicon -->
  <link href="./assets/img/brand/favicon.png" rel="icon" type="image/png">
  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
  <!-- Icons -->
  <link href="./assets/js/plugins/nucleo/css/nucleo.css" rel="stylesheet" />
  <link href="./assets/js/plugins/@fortawesome/fontawesome-free/css/all.min.css" rel="stylesheet" />
  <!-- CSS Files -->
  <link href="./assets/css/argon-dashboard.css?v=1.1.2" rel="stylesheet" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body class="">
  
 <!-- Header -->
 <?php
           include "headerback.php" ;
         ?>  

        <div class="" style="margin: auto;width: 75%;">
       
            <div class="container-fluid">
          
             <h3 id="dark-table">Ajouter Article</h3><br>
            

              <div class="tab-content">
                <div id="table-dark-component" class="tab-pane tab-example-result fade show active" role="tabpanel" aria-labelledby="table-dark-component-tab">

                
                  <caption><h1> </h1></caption><br><br>
                 
                <form method="POST" action="testAjoutarticleA.php" enctype="multipart/form-data">

                 <!--<caption> Ajouter client </caption> --> 
                <div>
                <p id="Error" style="color: #dc3545;"></p>  

                
                <input class="form-control" type="number" name="ref" placeholder="Reference" required="required" data-error="Reference is required."><br>

                
                <input class="form-control" type="text" name="nom" placeholder="Nom" required="required" data-error="Nom is required."><br>

                <i>categories</i>
                <select class="form-control" type="text" name="categorie" placeholder="categorie" required="required" data-error="categorie is required.">
                 <option>men</option>
                  <option>women</option>
                  <option>kids</option>
                  <option>vetment d'occation</option>
                </select><br>
                

                <input class="form-control" type="number" name="prix" placeholder="Prix" required="required" data-error="Prix is required."><br>

                <i>Size</i>
                <select class="form-control" type="text" name="size" placeholder="size" required="required" data-error="size is required.">
                  <option>S</option>
                  <option>M</option>
                  <option>L</option>
                  <option>XL</option>
                  <option>XXL</option>
                </select>
                <br>

                <i>color</i>
                <select class="form-control" type="text" name="color" placeholder="color" required="required" data-error="color is required.">
                  <option>Black</option>
                  <option>Pink</option>
                  <option>White</option>
                  <option>Blue</option>
                  <option>Orange</option>
                </select>
                <br>
                
                <!--<i class="fa fa-photo" aria-hidden="true"></i>
                <input id="photo" class="form_input input_photo input_ph" type="text" name="photo" placeholder="photo" required="required" data-error="photo is required."><br><br> -->

                <div class="form-group">
                          <label for="example-tel-input" class="form-control-label">Photo</label>
                          <input class="form-control" type="text" placeholder="Name Photo" name="photo" id="photo2" >
                                </div>
                                <div class="form-group">
                          <label for="example-tel-input" class="form-control-label">Photo</label>
                          <input class="form-control" type="file" placeholder="importer photo" name="pic" id="photo1">
                        </div>

                <!--<div class="form-group">
                          <label for="example-tel-input" class="form-control-label">Photo</label>
                          <input class="form-control" type="file" placeholder="importer photo" name="pic" id="photo1">-->
                        </div>


                </div>
                
                <div>
                <center><button id="review_submit" type="submit" class="btn btn-info" name="ajouter" value="ajouter" >
                  Ajouter </button> </center>
                </div>

                


              </form>
 
      </div>
    </div>
  </div>
</div>               
                 
  <!--   Core   -->
  <script src="./assets/js/plugins/jquery/dist/jquery.min.js"></script>
  <script src="./assets/js/plugins/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
  <!--   Optional JS   -->
  <script src="./assets/js/plugins/chart.js/dist/Chart.min.js"></script>
  <script src="./assets/js/plugins/chart.js/dist/Chart.extension.js"></script>
  <!--   Argon JS   -->
  <script src="./assets/js/argon-dashboard.min.js?v=1.1.2"></script>
  <script src="https://cdn.trackjs.com/agent/v3/latest/t.js"></script>
  <script>
    window.TrackJS &&
      TrackJS.install({
        token: "ee6fab19c5a04ac1a32a645abde4613a",
        application: "argon-dashboard-free"
      });
  </script>
</body>
</html>