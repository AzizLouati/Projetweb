<?PHP
include "../core/promotionC.php";
$promoC=new PromotionC();
if (isset($_POST["id_promo"]) && isset($_POST["ref"]))
{
	$state = 0 ;
	$ref = $_POST["ref"] ;
	$promoC->supprimerPromo($_POST["id_promo"]);
	$promoC->setEtatPromo($state,$ref) ;
	echo "<script>
          alert('suppression avec Succes');
          window.location='listePromo.php';
          </script>";
	//header('Location: listePromo.php');
}

?>