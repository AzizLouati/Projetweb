<?php
session_start();
include '../core/articleAC.php';
 include '../entities/articleA.php' ;
 $articleAc=new articleAC();

        if(isset($_POST["modif"]))
        { 
            $ref=$_POST['reff'];
          $sql="SELECT * from articleA where ref=$ref";
            $db = config::getConnexion();
            try{
            $liste=$db->query($sql);
            
            }
                catch (Exception $e){
                    die('Erreur: '.$e->getMessage());
            }
                foreach($liste as $row)
                {
                    $_SESSION['refff']=$row['ref'];
                    $ref=$row['ref'];
                    $nom=$row['nom'];
                    $categorie=$row['categorie'];
                    $prix=$row['prix'];
                    $size=$row['size'];
                    $color=$row['color']; 
                        $photo=$row['photo'] ;
                                

                }
        }        
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>
    >Modifier Article
  </title>
  <!-- Favicon -->
  <link href="./assets/img/brand/favicon.png" rel="icon" type="image/png">
  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
  <!-- Icons -->
  <link href="./assets/js/plugins/nucleo/css/nucleo.css" rel="stylesheet" />
  <link href="./assets/js/plugins/@fortawesome/fontawesome-free/css/all.min.css" rel="stylesheet" />
  <!-- CSS Files -->
  <link href="./assets/css/argon-dashboard.css?v=1.1.2" rel="stylesheet" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body class="">
  
 <!-- Header -->

        
        <?php
           include "headerback.php" ;
         ?>  
         <div class="" style="margin: auto;width: 75%;">
            <div class="container-fluid">
          
             <h3 id="dark-table">>Modifier Article</h3><br>
            

              <div class="tab-content">
                <div id="table-dark-component" class="tab-pane tab-example-result fade show active" role="tabpanel" aria-labelledby="table-dark-component-tab">

                
                  <caption><h1> </h1></caption><br><br>
                 
                <center><div class="col-lg-6 get_in_touch_col">
                <div class="get_in_touch_contents">
            
                        
                        <h1 style="color:#b9b4c7;">Modifier Article</h1><br><br>
                        <form method="POST" action="" enctype="multipart/form-data">

                                 <!--<caption> Ajouter client </caption> --> 
                                <div>
                                <p id="Error" style="color: #dc3545;"></p>  

                                <i style="color: white;" >Réference</i>
                                <input class="form-control" type="number" name="ref" placeholder="Reference" required="required" value="<?php echo $ref ?>" data-error="Reference is required.">
                                <input type="hidden" name="idd" value="<?php echo $ref ?>">
                                <br>

                                <i style="color: white;" >Nom</i>
                                <input class="form-control" type="text" name="nom" placeholder="Nom" required="required" value="<?php echo $nom ?>" data-error="Nom is required."><br>

                                
                                <i style="color: white;" >categories</i>
                                <select class="form-control" type="text" name="categorie" placeholder="categorie" required="required" value="<?php echo $categorie ?>"data-error="categorie is required.">
                                 <option>men</option>
                                  <option>women</option>
                                  <option>kids</option>
                                  <option>vetment d'occation</option>
                                </select><br>
                                
                                <i style="color: white;" >Prix</i>
                                <input class="form-control" type="number" name="prix" placeholder="Prix" required="required" value="<?php echo $prix ?>" data-error="Prix is required."><br>

                                
                                 <i style="color: white;">Size</i>
                                  <select class="form-control" type="text" name="size" placeholder="size" required="required"  value="<?php echo $size ?>"data-error="size is required.">
                                    <option>S</option>
                                    <option>M</option>
                                    <option>L</option>
                                    <option>XL</option>
                                    <option>XXL</option>
                                  </select>
                                  <br>

                              
                                <i style="color: white;">color</i>
                                <select class="form-control" type="text" name="color" placeholder="color" required="required" value="<?php echo $color ?>" data-error="color is required.">
                                  <option>Black</option>
                                  <option>Pink</option>
                                  <option>White</option>
                                  <option>Blue</option>
                                  <option>Orange</option>
                                </select>
                                <br>
                                
                                <!--<i class="fa fa-photo" aria-hidden="true"></i>
                                <input id="photo" class="form_input input_photo input_ph" type="text" name="photo" placeholder="photo" required="required" data-error="photo is required."><br><br> -->
                                <div class="form-group">
                                  <label for="example-tel-input" class="form-control-label">photo</label>
                                  <input class="form-control" type="text" placeholder="Name Photo" name="photo" id="photo2" >
                                </div>

                                <div class="form-group">
                                  <label for="example-tel-input" class="form-control-label">photo</label>
                                  <input class="form-control" type="file" placeholder="importer photo" name="pic" id="photo1" value="">
                                  <input type="hidden" name="img" value="<?php echo $photo ?>">
                                </div>

                                <!--<div class="form-group">
                                  <label for="example-tel-input" class="form-control-label">Photo</label>
                                  <input class="form-control" type="file" placeholder="importer photo" name="pic" id="photo1">
                                </div>-->


                                </div>
                                
                                <div>
                                <button id="review_submit" type="submit" class="red_button message_submit_btn trans_300" name="modifier" value="ajouter" >
                                    Modifier </button>   
                                </div>

                                


                        </form>
                    
                      </div>
                    </div>
                </center>
 
      </div>
    </div>
  </div>
</div>   

<?php
  if(isset($_POST["modifier"]))
  {
      $artC=new articleAC();    

    if (isset($_POST["pic"]) && !empty($_POST["pic"])) 
    {
        if (isset($_POST["ref"]) && isset($_POST["idd"]) && isset($_POST["nom"]) && isset($_POST["prix"]) && isset($_POST["categorie"]) && isset($_POST["color"]) && isset($_POST["size"])) 
        {
            if(!empty($_POST["ref"]) && !empty($_POST["idd"]) && !empty($_POST["nom"]) && !empty($_POST["prix"]) && !empty($_POST["categorie"]) && !empty($_POST["color"]) && !empty($_POST["size"]))
            {

                $art = new articleA($_POST["ref"],$_POST["nom"],$_POST["categorie"],$_POST["prix"],$_POST["size"],$_POST["color"],$_POST["pic"]);

                $artC->modifierarticleA($art,$_POST["idd"]) ; 

                 $adresse=$_FILES['pic']['name']; 
                 $uploads_dir = 'uploads';
               $target=basename($_FILES['pic']['name']);
               $tmp_name = $_FILES["pic"]["tmp_name"];
               //echo $_FILES['im']['size'];
               $ext=explode('.',$_FILES['pic']['name']);
               $extension=array('jpg','png','jpeg');
              if(in_array(strtolower(end($ext)),$extension)){
                $sql= "UPDATE  articleA set photo=:adresse where ref=:ref";
                $db = config::getConnexion();
                try{
                $req=$db->prepare($sql);
                $req->bindValue(':adresse',$adresse);
                $req->bindValue(':ref',$_POST["idd"]);
                $req->execute();
                }
                catch (Exception $e){
                    echo 'Erreur: '.$e->getMessage();
                }
                move_uploaded_file($tmp_name,"$uploads_dir/$target");
               }
                ?> 
                           
            <script type="text/javascript">
                window.location = "afficher_articleA.php" ;
            </script>
          <?php
            }
        }
    }
 
    if (isset($_POST["img"]) && !empty($_POST["img"])) 
    {
        if (isset($_POST["ref"]) && isset($_POST["idd"]) && isset($_POST["nom"]) && isset($_POST["prix"]) && isset($_POST["categorie"]) && isset($_POST["color"]) && isset($_POST["size"])) 
        {
        if(!empty($_POST["ref"]) && !empty($_POST["idd"]) && !empty($_POST["nom"]) && !empty($_POST["prix"]) && !empty($_POST["categorie"]) && !empty($_POST["color"]) && !empty($_POST["size"]))
        {

              $art = new articleA($_POST["ref"],$_POST["nom"],$_POST["categorie"],$_POST["prix"],$_POST["size"],$_POST["color"],$_POST["img"]);
              $artC->modifierarticlea($art,$_POST["idd"]) ;
          ?>             
            <script type="text/javascript">
                window.location = "afficher_articleA.php" ;
            </script>
      <?php

        }
      }

    }

  }

?>            
                 
  <!--   Core   -->
  <script src="./assets/js/plugins/jquery/dist/jquery.min.js"></script>
  <script src="./assets/js/plugins/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
  <!--   Optional JS   -->
  <script src="./assets/js/plugins/chart.js/dist/Chart.min.js"></script>
  <script src="./assets/js/plugins/chart.js/dist/Chart.extension.js"></script>
  <!--   Argon JS   -->
  <script src="./assets/js/argon-dashboard.min.js?v=1.1.2"></script>
  <script src="https://cdn.trackjs.com/agent/v3/latest/t.js"></script>
  <script>
    window.TrackJS &&
      TrackJS.install({
        token: "ee6fab19c5a04ac1a32a645abde4613a",
        application: "argon-dashboard-free"
      });
  </script>
</body>
</html>