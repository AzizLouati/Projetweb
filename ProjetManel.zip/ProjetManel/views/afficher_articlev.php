<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Afficher Articles</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="description" content="Colo Shop Template">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="styles/bootstrap4/bootstrap.min.css">
<link href="plugins/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/owl.carousel.css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/owl.theme.default.css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/animate.css">
<link rel="stylesheet" href="plugins/themify-icons/themify-icons.css">
<link rel="stylesheet" type="text/css" href="plugins/jquery-ui-1.12.1.custom/jquery-ui.css">
<link rel="stylesheet" type="text/css" href="styles/contact_styles.css">
<link rel="stylesheet" type="text/css" href="styles/contact_responsive.css">
</head>

<body>

<div class="super_container">

	<!-- Header -->
<?php
	 include 'header.php' ;
	   ?>
<!-- Slider -->

	<div class="main_slider" style="background-image:url(images/FondArticle.jpg)">
		<div class="container fill_height">
			<div class="row align-items-center fill_height">
				<div class="col">
					<div class="main_slider_content">
				</div>
			</div>
		</div>
	</div>
	<!-- Hamburger Menu -->
	<div class="container contact_container">
		<div class="row">
			<div class="col">

				<!-- Breadcrumbs -->

				<div class="breadcrumbs d-flex flex-row align-items-center">
					<ul>
						<li><a href="home.php">Home</a></li>
						<li><a href="profil.php"><i class="fa fa-angle-right" aria-hidden="true"></i>Profil</a></li>
						<li class="active"><a href="afficher_articlev.php"><i class="fa fa-angle-right" aria-hidden="true"></i>Liste de mes Articles</a></li>
						
					</ul>
				</div>
					<div>
					
			</div>
		</div>

	 <!-- row -->
	 	<?php 
	 			include '../core/articleC.php';
	
	$sql="select * from article";    /*changement qq chose on utilise:prepare, bindvalue puis execution*/ /*query si pa de changement*/
    $db=config :: getConnexion();
try 
    {
	$liste=$db->query($sql);
	
    }
    catch (Exception $e)
    {echo 'Echec' .$e->getMessage();}
	
	
	?>
	<!-- <form method="POST" action="afficher_articlev.php">-->
      
          <div class="col-md-12">
            <div class="content-panel">
            	<center><h2 style="color:#b9b4c7;"> Liste de mes Articles </h2></center><br><br><br><br>           
              <table class="table table-striped table-advance table-hover">
                 <a style="float: right;color: #E6E6FA;font-size: 24px;background: #2C799A;padding: 10px;border-radius: 5px;margin-bottom: 15px;" href="listePRomo.php">* Liste des Promotion *</a>
                <hr>
   				 <thead style="color:#6495ED;">
                  <tr>
                  	<td><center><i class="fa fa-picture-o"></i> Article</center></td>
                    <td><center><i class="fa fa-tags"></i> Reference</center></td>
                    <td><center><i class="fa fa-ticket"></i> Nom</center></td>
					<td><center><i class="fa fa-map-o"></i> Categorie</center></td> 
                    <td><center><i class="fa fa-stack-overflow "></i> Prix</center></td>
                    <td><center><i class="fa fa-stumbleupon"></i> Size</center></td>
                    <td><center><i class="fa fa-th-large"></i> Color</center></td>
                    <td><center><i class="fa fa-stack-exchange"></i> Action </center></td><td> </td>
                   
                  </tr>
                </thead>
                <?php
foreach($liste as $row){
	?>

	<tr style="color:#e9ecef;">
	<td><img width="75" height="75" src="uploads/<?PHP echo $row['photo']; ?>" class="rounded-circle m-r-5" alt=""></td>	
	<td><center><?PHP echo $row['ref']; ?></center></td>
	<td><center><?PHP echo $row['nom']; ?></center></td>
	<td><center><?PHP echo $row['categorie']; ?></center></td>
	<td><center><?PHP echo $row['prix']; ?>$</center></td>
	<td><center><?PHP echo $row['size']; ?></center></td>
	<td><center><?PHP echo $row['color']; ?></center></td>
	<!--<td><center><a onclick="return confirm('Are you sure you want to Remove?');" href="supprimerArticle.php"><i class="fa fa-trash-o m-r-5"></i></a></td>-->
   <td style="color:#4d7bca;">
   	<?php
   	 if($row['etatPromo'])
   	 {
   	 	echo "En promo . . ." ;
   	 }
   	 else
   	 {?>
   	 	 <form method="POST" action="ajouterPromo.php">
   	 	 	<input type="hidden" name="reff" value="<?PHP echo $row['ref']; ?>">
   	 	 	<input style="background:#2C799A; border:none;color: #E6E6FA;" type="submit" class="btn btn-info btn-xs" name="" value="Promotion">
   	 	 </form>

   	 <?php
   	  }
   	  ?>
   </td>
	<td>
	 <form  method="POST" action="./modifierArticle.php" >
							    
		  <input type="hidden"  name="reff" value="<?php echo $row['ref'];?>">
		  <center><button style="background: #172b4d;color:#5e72e4;border:none;" type="submit" name="modif" class="btn btn-info btn-xs" value="Modifier" onclick="return confirm('Are you sure you want to modify?');"><i class="fa fa-pencil" aria-hidden="true"></i></button></center>
	 </form>	
	 <form  method="POST" action="supprimerArticle.php" >
	 	   <input type="hidden"  name="reff" value="<?php echo $row['ref'];?>">
         	<center><button style="background: #172b4d;color: #007bff;border:none;" type="submit" name="sup" class="btn btn-danger btn-xs"  value="Supprimer" onclick="return confirm('Are you sure you want to Remove?');"><i class="fa fa-trash-o m-r-5"></i></button></center>
     </form>


	</td>
	
	</tr>
<?php
}

?>
                </table>
            </div>
      


	<!-- Newsletter -->

	<div class="newsletter">
		<div class="container">
			<div class="row">
				<div class="col-lg-6">
					<div class="newsletter_text d-flex flex-column justify-content-center align-items-lg-start align-items-md-center text-center">
						<h4>Newsletter</h4>
						<p>Subscribe to our newsletter and get 20% off your first purchase</p>
					</div>
				</div>
				<div class="col-lg-6">
					<form action="post">
						<div class="newsletter_form d-flex flex-md-row flex-column flex-xs-column align-items-center justify-content-lg-end justify-content-center">
							<input id="newsletter_email" type="email" placeholder="Your email" required="required" data-error="Valid email is required.">
							<button id="newsletter_submit" type="submit" class="newsletter_submit_btn trans_300" value="Submit">subscribe</button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>

	<!-- Footer -->

	<footer class="footer">
		<div class="container">
			<div class="row">
				<div class="col-lg-6">
					<div class="footer_nav_container d-flex flex-sm-row flex-column align-items-center justify-content-lg-start justify-content-center text-center">
						<ul class="footer_nav">
							<li><a href="#">Blog</a></li>
							<li><a href="#">FAQs</a></li>
							<li><a href="contact.php">Contact us</a></li>
						</ul>
					</div>
				</div>
				<div class="col-lg-6">
					<div class="footer_social d-flex flex-row align-items-center justify-content-lg-end justify-content-center">
						<ul>
							<li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
							<li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
							<li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
							<li><a href="#"><i class="fa fa-skype" aria-hidden="true"></i></a></li>
							<li><a href="#"><i class="fa fa-pinterest" aria-hidden="true"></i></a></li>
						</ul>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-lg-12">
					<div class="footer_nav_container">
						<div class="cr">©2018 All Rights Reserverd. Template by <a href="#">PatchWork</a></div>
					</div>
				</div>
			</div>
		</div>
	</footer>

</div>




<script src="js/jquery-3.2.1.min.js"></script>
<script src="styles/bootstrap4/popper.js"></script>
<script src="styles/bootstrap4/bootstrap.min.js"></script>
<script src="plugins/Isotope/isotope.pkgd.min.js"></script>
<script src="plugins/OwlCarousel2-2.2.1/owl.carousel.js"></script>
<script src="plugins/easing/easing.js"></script>
<script src="https://maps.googleapis.com/maps/api/js?v=3.exp&key=AIzaSyCIwF204lFZg1y4kPSIhKaHEXMLYxxuMhA"></script>
<script src="plugins/jquery-ui-1.12.1.custom/jquery-ui.js"></script>
<script src="js/contact_custom.js"></script>
</body>

</html>
