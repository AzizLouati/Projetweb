<?php
  include "../core/promotionAC.php" ;
  include  "../entities/promotionA.php";
if(isset($_POST["modifier"]))
{
 if( isset($_POST['idPromo']) && isset($_POST['ref'])  && isset($_POST['dateFin']) && isset($_POST['dateDebut']) && isset($_POST['remise']) && isset($_POST['idd']))
        {
          if(!empty($_POST['idPromo']) && !empty($_POST['ref']) && !empty($_POST['dateDebut']) && !empty($_POST['dateFin']) && !empty($_POST['remise']) && !empty($_POST['idd']) )
          {
              $proA=new PromotionA($_POST['idPromo'],$_POST['ref'],$_POST['dateDebut'],$_POST['dateFin'],$_POST['remise']);
              $proAC = new PromotionAC () ;
              $proAC->modifierPromotionA($proA,$_POST['idd']) ; 
             //header('Location: listePromoA.php');
              //echo "string";?>
              <script type="text/javascript">
                alert("promotionA modifiée avec success") ;
                window.location="listePromoA.php" ;
              </script>
         <?php }
          else { echo "empty" ;}

        }else { echo "empty" ; }
}
?>