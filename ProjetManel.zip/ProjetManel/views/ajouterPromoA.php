<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>
    Ajouter Promotion
  </title>
  <!-- Favicon -->
  <link href="./assets/img/brand/favicon.png" rel="icon" type="image/png">
  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
  <!-- Icons -->
  <link href="./assets/js/plugins/nucleo/css/nucleo.css" rel="stylesheet" />
  <link href="./assets/js/plugins/@fortawesome/fontawesome-free/css/all.min.css" rel="stylesheet" />
  <!-- CSS Files -->
  <link href="./assets/css/argon-dashboard.css?v=1.1.2" rel="stylesheet" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body class="">
  
 <!-- Header -->
   <?php
       include "headerback.php" ;
       include '../core/articleAC.php' ;
     if(isset($_POST['reff'])) ;
     {
       $artC = new articleAC() ;
       $list = $artC->recupererarticleA($_POST['reff']) ;
       if(!empty($list))
       {
        foreach ($list as $row) {
          $photo = $row["photo"] ;
          $prix = $row["prix" ] ;
          $ref = $row["ref"] ;
          $nom = $row["nom"] ;
        }
       }
     }
   ?>
        <div class="" style="margin: auto;width: 75%;">
         

            <div class="container-fluid">
          
             <h3 id="dark-table">Ajouter Promotion</h3><br>
            

              <div class="tab-content">
                <div id="table-dark-component" class="tab-pane tab-example-result fade show active" role="tabpanel" aria-labelledby="table-dark-component-tab">

                
                  <caption><h1> </h1></caption><br><br>
                 
                <form method="POST" action="testAjoutPromoA.php" enctype="multipart/form-data">
              <div class="row">
                <div class="col-lg-6">
                    <input class="form-control" type="number" name="idPromo" placeholder="id promotion" required="required" data-error="id promotion is required."><br><br>
                    <input type="hidden" name="ref" value="<?php echo $ref ?>">
                
                  <input class="form-control" type="date" name="dateDebut" placeholder="Date Debut" required="required" data-error="date is required."><br><br>

                  
                  <input class="form-control" type="date" name="dateFin" placeholder="Date Fin" required="required" data-error="Date fin is required."><br><br>
                  
                  
                  <input class="form-control" type="number" name="remise" placeholder="Remise" required="required" data-error="Remise is required."><br><br>
                  </div>
                  <div class="col-lg-6">
                    <p style="margin-left: 120px;color: white"><?php echo $nom; ?></p>
                     <img src="uploads/<?php echo $photo ; ?>" style="max-width: 300px;max-height: 350px;">
                     <br>
                     <p style="margin-left: 120px;color: white;margin-top: 20px;"><?php echo $prix; ?> DNT</p>
                </div>
              </div>

            <div>
                <button style="margin-left: 120px;" id="review_submit" type="submit" class="btn btn-info" name="ajouter" value="ajouter" >
                  Ajouter </button> 
            </div>

              </form>
 
      </div>
    </div>
  </div>
</div>               
                 
  <!--   Core   -->
  <script src="./assets/js/plugins/jquery/dist/jquery.min.js"></script>
  <script src="./assets/js/plugins/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
  <!--   Optional JS   -->
  <script src="./assets/js/plugins/chart.js/dist/Chart.min.js"></script>
  <script src="./assets/js/plugins/chart.js/dist/Chart.extension.js"></script>
  <!--   Argon JS   -->
  <script src="./assets/js/argon-dashboard.min.js?v=1.1.2"></script>
  <script src="https://cdn.trackjs.com/agent/v3/latest/t.js"></script>
  <script>
    window.TrackJS &&
      TrackJS.install({
        token: "ee6fab19c5a04ac1a32a645abde4613a",
        application: "argon-dashboard-free"
      });
  </script>
</body>
</html>