<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>
    Liste des ArticlesA
  </title>

   <!-- Favicon -->
  <link href="./assets/img/brand/favicon.png" rel="icon" type="image/png">
  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
  <!-- Icons -->
  <link href="./assets/js/plugins/nucleo/css/nucleo.css" rel="stylesheet" />
  <link href="./assets/js/plugins/@fortawesome/fontawesome-free/css/all.min.css" rel="stylesheet" />
  <!-- CSS Files -->
  <link href="./assets/css/argon-dashboard.css?v=1.1.2" rel="stylesheet" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

  <script type="text/javascript">
          function printDiv(divName) {
            var printContents = document.getElementById(divName).innerHTML;
            var originalContents = document.body.innerHTML;

            document.body.innerHTML = printContents;
            window.print();
            document.body.innerHTML = originalContents;
        }

         function trierPar()
         {
          var input = document.getElementById("tri").value  ;
          window.location="afficher_articleA.php?tri="+input;
        }
       </script>
</head>

<body class="">

 <!-- Header -->

        <div class="">
        <?php
           include "headerback.php" ;
           include '../core/articleAC.php';
           $art = new articleAC() ;
           $list=$art->afficherarticleA() ; 
           if(isset($_GET['search']))
             {
              $list = $art->rechercherarticleA($_GET['search']) ;
             }
          if (!empty($list)) {  ?> 
          <div class="cont" id="divarticleA">
             <!--<table class="table dark-table" style="margin: auto;width: 95%;text-align: center;" >-->  
             <div class="header bg-gradient-primary pb-8 pt-5 pt-md-8">
 
             <!--<caption><h1> </h1></caption><br><br><br><br> 
              <input type="search" name="search" id="rechercher" onsearch="rechercher() ;" style="margin-bottom: 50px;width: 40%;height: 40px;">  -->

            <div class="container-fluid">
          
             <h3 id="dark-table">Liste des Articles</h3><br>
             <div>

              <div class="tab-content">
                <div id="table-dark-component" class="tab-pane tab-example-result fade show active" role="tabpanel" aria-labelledby="table-dark-component-tab">

                  <form class="navbar-search navbar-search-dark form-inline mr-3 d-none d-md-flex ml-lg-auto">
                    <div class="form-group mb-0">
                      <div class="input-group input-group-alternative">
                        <div class="input-group-prepend">
                          <span class="input-group-text"><i class="fas fa-search"></i></span>
                        </div>
                          <input class="form-control" placeholder="Search" type="search" name="search" id="rechercher" onsearch="rechercher() ;"><br><br>
                      </div>
                    </div>
                    <div style="margin-left: 20px; ">
                    <div class="print">
                        <select style="background:#1c345d; color: #87CEEB; border:none;" id="tri" class="form-control" onchange="trierPar();"> 
                            <option value="0">>>Filtrer<<</option>
                            <option value="ref_up">Reférence Croissant</option>
                            <option value="ref_down">Reférence Decroissant</option>
                            <option value="name_up">Nom A .. Z</option>
                            <option value="name_down">Nom Z .. A</option>
                            <option value="prix_up">Prix Croissant</option>
                            <option value="prix_down">Prix Decroissant</option>
                          </select>
                          <i class="fa fa-print "  style="margin-right: 50px; font-size: 28px; color:#32325d;" onclick="printDiv('divarticleA');"></i> 

                    </div>
                </div>
                </div>
                 <a style="margin-left:700px;background: #483D8B;border:none;color: #D8BFD8;" class="btn btn-info btn-xs" href="ajouterarticleA.php">+ Ajouter Article</a>
                 <a style="margin-left:690px;background: #483D8B;border:none;color: #D8BFD8;" class="btn btn-info btn-xs" href="listePromoA.php">* Liste Promotion *</a>
                  </form>

                        <?php
           $artC = new articleAC() ;
           $mylist=$artC->afficherarticleA() ; 
           if(isset($_GET['search']))
             {
              $mylist = $artC->rechercherarticleA($_GET['search']) ;
             }

            if(isset($_GET['tri']))
             {
              if($_GET['tri'] == "ref_up")
              {
                $mylist= $artC->TrierarticleA('ref','asc') ;
              }
              else if($_GET['tri'] == "ref_down")
              {
                $mylist= $artC->TrierarticleA('ref','desc') ;
              }
              else if($_GET['tri'] == "name_up")
              {
                $mylist= $artC->TrierarticleA('nom','asc') ;
              }
              else if($_GET['tri'] == "name_down")
              {
                $mylist= $artC->TrierarticleA('nom','desc') ;
              }
               else if($_GET['tri'] == "prix_up")
              {
                $mylist= $artC->TrierarticleA('prix','asc') ;
              }
              else if($_GET['tri'] == "prix_down")
              {
                $mylist= $artC->TrierarticleA('prix','desc') ;
              }
              
             }
         if (!empty($mylist)) {  ?>
          
              <table class="table align-items-center table-dark">
                    <thead class="thead-dark"> 
                      
                  <th><i class="fa fa-picture-o"></i> Article</th>
                  <th><i class="fa fa-tags"></i> Reférence</th>
                  <th><i class="fa fa-ticket"></i> Nom</th>
                  <th><i class="fa fa-map-o"></i> Categorie</th>
                  <th><i class="fa fa-stack-overflow "></i> Prix</th>
                  <th><i class="fa fa-stumbleupon"></i> Size</th>
                  <th><i class="fa fa-th-large"></i> Color</th>
                  <th><center><i class="fa fa-stack-exchange"></i> Action</center></th>
                  <th> </th>
                </thead>
             <tbody>
              <?php
                  foreach ($mylist as $row) {
              ?>
              <tr>
                <td><img width="75" height="75" src="uploads/<?PHP echo $row['photo']; ?>" class="rounded-circle m-r-5" alt=""></td>
                <td><center><?php echo $row['ref'] ; ?></center></td>
                <td><center><?php echo $row['nom'] ; ?></center></td>
                <td><center><?php echo $row['categorie'] ; ?></center></td>
                <td><center><?php echo $row['prix'] ; ?></center></td>
                <td><center><?php echo $row['size'] ; ?></center></td>
                <td><center><?php echo $row['color'] ; ?></center></td>
                </td>
                <td style="color:#40E0D0;"><center>
                <?php
                 if($row['etatPromoA'])
                 {
                   echo "En promo . . ." ;
                 }
                 else
                 {?>
                   <form method="POST" action="ajouterPromoA.php">
                    <input type="hidden" name="reff" value="<?PHP echo $row['ref']; ?>">
                    <input style="background:#2C799A; border:none;color: #E6E6FA;" type="submit" class="btn btn-info btn-xs" name="" value=" Promotion">
                   </form>

                 <?php
                  }
                  ?></center>
                  </td>
                  <td>
                   <form  method="POST" action="./modifierArticleA.php" >
                                  
                      <input type="hidden"  name="reff" value="<?php echo $row['ref'];?>">
                      <center><button style="background: #172b4d;color:#5e72e4;border:none;" type="submit" name="modif" value="Modifier" class="btn btn-info btn-xs" onclick="return confirm('Are you sure you want to modify?');"><i class="fa fa-pencil" aria-hidden="true"></i></button></center>
                   </form>
                   
                   <form  method="POST" action="supprimerArticleA.php" >
                   <input type="hidden"  name="reff" value="<?php echo $row['ref'];?>">
                      <center><button style="background: #172b4d;color: #007bff;border:none;" type="submit" name="sup" class="btn btn-danger btn-xs"  value="Supprimer" onclick="return confirm('Are you sure you want to Remove?');"><i class="fa fa-trash-o m-r-5" aria-hidden="true"></i></button></center>
                 </form> 
                   </td>  
                </tr>
            <?php
                      }
 
                 }
            ?>
                  <caption><h1> </h1></caption><br><br>
                 
                
          <?php
           }
          ?>
        </tbody>
      </table>
       <?php
           
          ?>
      </div>
  </div>

  <script type="text/javascript">
         function rechercher(){
          var input = document.getElementById("rechercher").value ;
          window.location="afficher_articleA.php?search="+input; 
         }
       </script>

         </table>
                </div>
              </div>
            </div>
           
      
                </div>
                 
           
        </div>


</body>
</html>