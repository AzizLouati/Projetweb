<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>
    Liste des Promotion
  </title>

   <!-- Favicon -->
  <link href="./assets/img/brand/favicon.png" rel="icon" type="image/png">
  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
  <!-- Icons -->
  <link href="./assets/js/plugins/nucleo/css/nucleo.css" rel="stylesheet" />
  <link href="./assets/js/plugins/@fortawesome/fontawesome-free/css/all.min.css" rel="stylesheet" />
  <!-- CSS Files -->
  <link href="./assets/css/argon-dashboard.css?v=1.1.2" rel="stylesheet" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

  <script type="text/javascript">
          function printDiv(divName) {
            var printContents = document.getElementById(divName).innerHTML;
            var originalContents = document.body.innerHTML;

            document.body.innerHTML = printContents;
            window.print();
            document.body.innerHTML = originalContents;
        }

         function trierPar()
         {
          var input = document.getElementById("tri").value  ;
          window.location="listePromoA.php?tri="+input;
        }
       </script>
       <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
</head>

<body class="">

 <!-- Header -->

        <div class="">
        <?php
           include "headerback.php" ;
           include '../core/promotionAC.php';
           $promo = new promotionAC() ;
           $list=$promo->afficherPromotionA() ;
           $EnPromo = $promo->getAllrowsEtat(1) ; 
           $PasEnPromo = $promo->getAllrowsEtat(0) ; 
           if(isset($_GET['search']))
             {
              $list = $promo->rechercherPromotionA($_GET['search']) ;
             }
          if (!empty($list)) {  ?> 
          <div class="cont" id="divPromotionA">
             <!--<table class="table dark-table" style="margin: auto;width: 95%;text-align: center;" >-->  
             <div class="header bg-gradient-primary pb-8 pt-5 pt-md-8">
 
             <!--<caption><h1> </h1></caption><br><br><br><br> 
              <input type="search" name="search" id="rechercher" onsearch="rechercher() ;" style="margin-bottom: 50px;width: 40%;height: 40px;">  -->

            <div class="container-fluid">
          
             <h3 id="dark-table">Liste des Promotion</h3><br>
             <div>

              <div class="tab-content">
                <div id="table-dark-component" class="tab-pane tab-example-result fade show active" role="tabpanel" aria-labelledby="table-dark-component-tab">

                  <form class="navbar-search navbar-search-dark form-inline mr-3 d-none d-md-flex ml-lg-auto">
                    <div class="form-group mb-0">
                      <div class="input-group input-group-alternative">
                        <div class="input-group-prepend">
                          <span class="input-group-text"><i class="fas fa-search"></i></span>
                        </div>
                          <input class="form-control" placeholder="Search" type="search" name="search" id="rechercher" onsearch="rechercher() ;"><br><br>
                      </div>
                    </div>
                     <div style="margin-left: 20px; ">
                    <div class="print">
                        <select style="background:#1c345d; color: #87CEEB; border:none;" id="tri" class="form-control" onchange="trierPar();"> 
                            <option class="fa fa-sliders " value="0">>>Filtrer<<</option>
                            <option class="fa fa-sort-amount-asc" value="prix_up">Prix Croissant</option>
                            <option class="fa fa-sort-amount-desc" value="prix_down">Prix Decroissant</option>
                            <option class="fa fa-sort-alpha-asc" value="name_up">Nom A .. Z</option>
                            <option class="fa fa-sort-alpha-desc" value="name_down">Nom Z .. A</option>
                            <option class="fa fa-sort-amount-asc" value="remise_up">Remise Croissant</option>
                            <option class="fa fa-sort-amount-desc " value="remise_down">Remise Decroissant</option>
                          </select>
                          <i class="fa fa-print " style="margin-right: 50px; font-size: 28px; color:#32325d;" onclick="printDiv('divPromotionA');"></i>
                    </div>
                </div>
                 </div>
                <a style="margin-left:650px;background: #483D8B;border:none;color: #D8BFD8;" class="btn btn-info btn-xs" href="afficher_articleA.php">+ Ajouter Promotion</a>
                  </form>
                        <?php
           $promoC = new PromotionAC() ;
           $mylist=$promoC->afficherPromotionA() ; 
           if(isset($_GET['search']))
             {
              $mylist = $promoC->rechercherPromotionA($_GET['search']) ;
             }

            if(isset($_GET['tri']))
             {
              if($_GET['tri'] == "prix_up")
              {
                $mylist= $promoC->TrierPromotionA('prix','asc') ;
              }
              else if($_GET['tri'] == "prix_down")
              {
                $mylist= $promoC->TrierPromotionA('prix','desc') ;
              }
              else if($_GET['tri'] == "name_up")
              {
                $mylist= $promoC->TrierPromotionA('nom','asc') ;
              }
              else if($_GET['tri'] == "name_down")
              {
                $mylist= $promoC->TrierPromotionA('nom','desc') ;
              }
              else if($_GET['tri'] == "remise_up")
              {
                $mylist= $promoC->TrierPromotionA('remise','asc') ;
              }
              else if($_GET['tri'] == "remise_down")
              {
                $mylist= $promoC->TrierPromotionA('remise','desc') ;
              }
              
             }
         if (!empty($mylist)) {  ?>
          
              <table class="table align-items-center table-dark">
                    <thead class="thead-dark"> 

                  <th><center><i class="fa fa-shopping-basket"></i></center></th>
                  <th><center>ID</center></th>
                  <th><center>Ref</center></th>
                  <th><center>Nom</center></th>
                  <th><center>% Remise</center></th>
                  <th><center><i class="fa fa-th-large"></i> DateDebut</center></th>
                  <th><center><i class="fa fa-th-large"></i> DateFin</center></th>
                  <th><center><i class="fa fa-stack-overflow "></i> Prixavant</center></th>
                  <th><center><i class="fa fa-stack-overflow "></i> Prixapres</center></th>
                  <th><center><i class="fa fa-stack-exchange"></i> Action</center></th>
                </thead>
             <tbody>
              <?php
                  foreach ($mylist as $row) {
              ?>
              <tr>
                <td><img width="75" height="75" src="uploads/<?PHP echo $row['photo']; ?>" class="rounded-circle m-r-5" alt=""></center></td>  
                  <td><center><?PHP echo $row['id_promo']; ?></center></td>
                  <td><center><?PHP echo $row['reff']; ?></center></td>
                  <td><center><?PHP echo $row['nom']; ?></center></td>
                  <td><center><?PHP echo $row['remise']; ?> %</center></td>
                  <td><center><?PHP echo $row['dateDebut']; ?></center></td>
                  <td><center><?PHP echo $row['dateFin']; ?></center></td>
                  <td><center><?PHP echo $row['prix']; ?> $</center></td>
                  <td><center><?PHP echo ($row['prix'] - (($row['prix']*$row['remise'])/100)) ; ?> $</center></td>
                  <td>
                

                   <form  method="POST" action="./modifierPromoA.php" >
                                  
                     <input type="hidden"  name="id_promo" value="<?php echo $row['id_promo'];?>">
                      <center><button style="background: #172b4d;color:#5e72e4;border:none;" type="submit" name="modif" class="btn btn-info btn-xs" value="Modifier" onclick="return confirm('Are you sure you want to modify?');"><i class="fa fa-pencil" aria-hidden="true"></i></button></center>
                   </form> 
                   <form  method="POST" action="supprimerPromoA.php" >
                    <input type="hidden" name="ref" value="<?PHP echo $row['reff']; ?>">
                         <input type="hidden"  name="id_promo" value="<?php echo $row['id_promo'];?>">
                      <center><button style="background: #172b4d;color: #007bff;border:none;" type="submit" name="sup" class="btn btn-danger btn-xs"  value="Supprimer" onclick="return confirm('Are you sure you want to Remove?');"><i class="fa fa-trash-o m-r-5" aria-hidden="true"></i></button></center>
                 </form> 
                   </td>  
                </tr>
            <?php
                      }
 
                 }
            ?>
                  <caption><h1> </h1></caption><br><br>
                 
                
          <?php
           }
          ?>
        </tbody>
      </table>
       <?php
           
          ?>
      </div>
      <h3>Stat Promotion</h3><br><br>
      <div class="row">
        <div class="col">
          <div id="columnchart_values" style="width: 600px; height: 500px;float: left;background-color: lightgray;"></div> 
        </div>
    </div>
  </div>



  <script type="text/javascript">
              google.charts.load("current", {packages:['corechart']});
              google.charts.setOnLoadCallback(drawChart);
              function drawChart() {
                var data = google.visualization.arrayToDataTable([
                  ["", "", { role: "style" } ],
                  ["En Promo",<?php echo $EnPromo; ?>, "#c3d6f7"],
                  ["Pas de Promo",<?php echo $PasEnPromo;?>, "#456b53"],
                ]);

                var view = new google.visualization.DataView(data);
                view.setColumns([0, 1,
                                 { calc: "stringify",
                                   sourceColumn: 1,
                                   type: "string",
                                   role: "annotation" },
                                 2]);

                var options = {
                  title: "",
                  width: 600,
                  height: 500,
                  bar: {groupWidth: "95%"},
                  legend: { position: "none" },
                };
                var chart = new google.visualization.ColumnChart(document.getElementById("columnchart_values"));
                chart.draw(view, options);
            }
  </script>

  <script type="text/javascript">
         function rechercher(){
          var input = document.getElementById("rechercher").value ;
          window.location="afficher_PromotionA.php?search="+input; 
         }
       </script>

         </table>
                </div>
              </div>
            </div>
           
      
                </div>
                 
           
        </div>


</body>
</html>