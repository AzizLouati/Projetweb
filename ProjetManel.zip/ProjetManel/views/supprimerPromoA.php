<?PHP
include "../core/promotionAC.php";
$promoAC=new PromotionAC();
if (isset($_POST["id_promo"]) && isset($_POST["ref"]))
{
  $state = 0 ;
  $ref = $_POST["ref"] ;
  $promoAC->supprimerPromoA($_POST["id_promo"]);
  $promoAC->setEtatPromoA($state,$ref) ;
  echo "<script>
          alert('suppression avec Succes');
          window.location='listePromoA.php';
          </script>";
  //header('Location: listePromoA.php');
}

?>