 <?php

     include '../core/clientC.php';
     include '../entities/client.php';
     if(isset($_POST['nom']) && isset($_POST['prenom']) && isset($_POST['email']) && isset($_POST['password']) && isset($_POST['address']) && isset($_POST['phone']))
        {
          if(!empty($_POST['nom']) && !empty($_POST['prenom']) && !empty($_POST['email']) && !empty($_POST['password']) && !empty($_POST['address']) && !empty($_POST['phone']) )
          {
             $nom=$_POST['nom'] ;
             $prenom=$_POST['prenom'] ;
             $email=$_POST['email'] ;
             $password=$_POST['password'] ;
             $address=$_POST['address'] ;
             $phone=$_POST['phone'] ;
             $clt=new Client(0,$nom,$prenom,$email,$password,$address,$phone);   
             $cltC=new ClientC() ;
             $test=$cltC->ajouterClient($clt) ;
             if($test==true)
             { $to = $email ;
                $subject = "compte crée avec success";
                $message = "Bonjour , \n PAtchwork vous remercie pour votre confiance  \n votre compte a été bien crée vous pouvez connectez avec votre login : $email et mot de passe : $password  \n Bonne journée.";
                $retval = mail ($to,$subject,$message);
                   echo "<script>
                    alert('Register avec Succes');
                    window.location.href='home.php';
                    </script>";
                //header('Location: home.php');
             }

             else{
              echo "Echec";
            }
           }else { echo "champ vide";}

        }else { echo "champ manquant";}
?>