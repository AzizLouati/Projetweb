<?PHP
include "../core/articleC.php";
$art=new articleC();
if (isset($_POST["reff"]))
{
	$art->supprimerarticle($_POST["reff"]);
    echo "<script>
          alert('Suppression avec Succes');
          window.location='afficher_articlev.php';
          </script>";
	//header('Location: listeArticle.php');
}

?>
