<?php
 session_start() ;
 include '../core/articleC.php';
 include '../entities/article.php' ;
 $articlec=new articleC();

        if(isset($_POST["modif"]))
        { 
            $ref=$_POST['reff'];
        	$sql="SELECT * from article where ref=$ref";
        		$db = config::getConnexion();
        		try{
        		$liste=$db->query($sql);
        		
        		}
                catch (Exception $e){
                    die('Erreur: '.$e->getMessage());
        		}
                foreach($liste as $row)
                {
                		$_SESSION['refff']=$row['ref'];
                		$ref=$row['ref'];
                		$nom=$row['nom'];
        				$categorie=$row['categorie'];
                		$prix=$row['prix'];
                		$size=$row['size'];
                		$color=$row['color']; 
                        $photo=$row['photo'] ;
                             		

                }
        }        
?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>Modifier Article</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="description" content="Colo Shop Template">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="styles/bootstrap4/bootstrap.min.css">
<link href="plugins/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/owl.carousel.css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/owl.theme.default.css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/animate.css">
<link rel="stylesheet" href="plugins/themify-icons/themify-icons.css">
<link rel="stylesheet" type="text/css" href="plugins/jquery-ui-1.12.1.custom/jquery-ui.css">
<link rel="stylesheet" type="text/css" href="styles/contact_styles.css">
<link rel="stylesheet" type="text/css" href="styles/contact_responsive.css">
</head>

<body>

<div class="super_container">

    <!-- Header -->
  <?php
     include 'header.php'
  ?>


<!-- Slider -->

    <div class="main_slider" style="background-image:url(images/bleu.jpg)">
        <div class="container fill_height">
            <div class="row align-items-center fill_height">
                <div class="col">
                    <div class="main_slider_content">
                </div>
            </div>
        </div>
    </div>
    <div class="container contact_container">
        <div class="row">
            <div class="col">

                <!-- Breadcrumbs -->

                <div class="breadcrumbs d-flex flex-row align-items-center">
                    <ul>
                        <li><a href="home.php">Home</a></li>
                        <li><a href="profil.php"><i class="fa fa-angle-right" aria-hidden="true"></i>Profil</a></li>
                        <li><a href="afficher_articlev.php"><i class="fa fa-angle-right" aria-hidden="true"></i>Liste de mes Articles
                        </a></li>
                        <li class="active"><a href="modifierArticle.php"><i class="fa fa-angle-right" aria-hidden="true"></i>Modifier Article</a></li>
                    </ul>
                </div>

            </div>
        </div>

            <!-- Slider -->

            <center><div class="col-lg-6 get_in_touch_col">
                <div class="get_in_touch_contents">
            
                        
                        <h1 style="color:#b9b4c7;">Modifier Article</h1><br><br>
                        <form method="POST" action="" enctype="multipart/form-data">

                                 <!--<caption> Ajouter client </caption> --> 
                                <div>
                                <p id="Error" style="color: #dc3545;"></p>  

                                <i style="color: white;">Réference</i>
                                <input class="form-control" type="number" name="ref" placeholder="Reference" required="required" value="<?php echo $ref ?>" data-error="Reference is required.">
                                <input type="hidden" name="idd" value="<?php echo $ref ?>">
                                <br>

                                <i style="color: white;">Nom</i>
                                <input class="form-control" type="text" name="nom" placeholder="Nom" required="required" value="<?php echo $nom ?>" data-error="Nom is required."><br>

                                
                                <i style="color: white;">categories</i>
                                <select class="form-control" type="text" name="categorie" placeholder="categorie" required="required"  value="<?php echo $categorie ?>" data-error="categorie is required.">
                                 <option>men</option>
                                  <option>women</option>
                                  <option>kids</option>
                                  <option>vetment d'occation</option>
                                </select><br>
                                
                                <i style="color: white;">Prix</i>
                                <input class="form-control" type="number" name="prix" placeholder="Prix" required="required" value="<?php echo $prix ?>" data-error="Prix is required."><br>

                                
                
                                <i style="color: white;">Size</i>
                                <select class="form-control" type="text" name="size" placeholder="size" required="required" value="<?php echo $size ?>" data-error="size is required.">
                                  <option>S</option>
                                  <option>M</option>
                                  <option>L</option>
                                  <option>XL</option>
                                  <option>XXL</option>
                                </select>
                                <br>

                                
                                
                                <i style="color: white;">color</i>
                                <select class="form-control" type="text" name="color" placeholder="color" required="required" value="<?php echo $color ?>" data-error="color is required.">
                                  <option>Black</option>
                                  <option>Pink</option>
                                  <option>White</option>
                                  <option>Blue</option>
                                  <option>Orange</option>
                                </select>
                                <br>
                                
                                <!--<i class="fa fa-photo" aria-hidden="true"></i>
                                <input id="photo" class="form_input input_photo input_ph" type="text" name="photo" placeholder="photo" required="required" data-error="photo is required."><br><br> -->
                                <div class="form-group">
                                  <label for="example-tel-input" class="form-control-label">photo</label>
                                  <input class="form-control" type="text" placeholder="Name Photo" name="photo" id="photo2" >
                                </div>

                                <div class="form-group">
                                  <label for="example-tel-input" class="form-control-label">photo</label>
                                  <input class="form-control" type="file" placeholder="importer photo" name="pic" id="photo1" value="">
                                  <input type="hidden" name="img" value="<?php echo $photo ?>">
                                </div>

                                <!--<div class="form-group">
                                  <label for="example-tel-input" class="form-control-label">Photo</label>
                                  <input class="form-control" type="file" placeholder="importer photo" name="pic" id="photo1">
                                </div>-->


                                </div>
                                
                                <div>
                                <button id="review_submit" type="submit" class="red_button message_submit_btn trans_300" name="modifier" value="ajouter" >
                                    Modifier </button>   
                                </div>

                                


                        </form>
                    
                      </div>
                    </div>
                </center>
                
            
    <!-- Newsletter -->

    <div class="newsletter">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="newsletter_text d-flex flex-column justify-content-center align-items-lg-start align-items-md-center text-center">
                        <h4>Newsletter</h4>
                        <p>Subscribe to our newsletter and get 20% off your first purchase</p>
                    </div>
                </div>
                <div class="col-lg-6">
                    <form action="post">
                        <div class="newsletter_form d-flex flex-md-row flex-column flex-xs-column align-items-center justify-content-lg-end justify-content-center">
                            <input id="newsletter_email" type="email" placeholder="Your email" required="required" data-error="Valid email is required.">
                            <button id="newsletter_submit" type="submit" class="newsletter_submit_btn trans_300" value="Submit">subscribe</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->

    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="footer_nav_container d-flex flex-sm-row flex-column align-items-center justify-content-lg-start justify-content-center text-center">
                        <ul class="footer_nav">
                            <li><a href="#">Blog</a></li>
                            <li><a href="#">FAQs</a></li>
                            <li><a href="contact.html">Contact us</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="footer_social d-flex flex-row align-items-center justify-content-lg-end justify-content-center">
                        <ul>
                            <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                            <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                            <li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
                            <li><a href="#"><i class="fa fa-skype" aria-hidden="true"></i></a></li>
                            <li><a href="#"><i class="fa fa-pinterest" aria-hidden="true"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="footer_nav_container">
                        <div class="cr">©2018 All Rights Reserverd. Template by <a href="#">Colorlib</a></div>
                    </div>
                </div>
            </div>
        </div>
    </footer>

</div>
</div>
</div>
</div>

<?php
  if(isset($_POST["modifier"]))
  {
      $artC=new articleC();    

    if (isset($_POST["pic"]) && !empty($_POST["pic"])) 
    {
        if (isset($_POST["ref"]) && isset($_POST["idd"]) && isset($_POST["nom"]) && isset($_POST["prix"]) && isset($_POST["categorie"]) && isset($_POST["color"]) && isset($_POST["size"])) 
        {
            if(!empty($_POST["ref"]) && !empty($_POST["idd"]) && !empty($_POST["nom"]) && !empty($_POST["prix"]) && !empty($_POST["categorie"]) && !empty($_POST["color"]) && !empty($_POST["size"]))
            {

                $art = new article($_POST["ref"],$_POST["nom"],$_POST["categorie"],$_POST["prix"],$_POST["size"],$_POST["color"],$_POST["pic"]);

                $artC->modifierarticle($art,$_POST["idd"]) ; 

                 $adresse=$_FILES['pic']['name']; 
                 $uploads_dir = 'uploads';
               $target=basename($_FILES['pic']['name']);
               $tmp_name = $_FILES["pic"]["tmp_name"];
               //echo $_FILES['im']['size'];
               $ext=explode('.',$_FILES['pic']['name']);
               $extension=array('jpg','png','jpeg');
              if(in_array(strtolower(end($ext)),$extension)){
                $sql= "UPDATE  article set photo=:adresse where ref=:ref";
                $db = config::getConnexion();
                try{
                $req=$db->prepare($sql);
                $req->bindValue(':adresse',$adresse);
                $req->bindValue(':ref',$_POST["idd"]);
                $req->execute();
                }
                catch (Exception $e){
                    echo 'Erreur: '.$e->getMessage();
                }
                move_uploaded_file($tmp_name,"$uploads_dir/$target");
               }
                ?> 
                           
            <script type="text/javascript">
                window.location = "afficher_articlev.php" ;
            </script>
          <?php
            }
        }
    }
 
    if (isset($_POST["img"]) && !empty($_POST["img"])) 
    {
        if (isset($_POST["ref"]) && isset($_POST["idd"]) && isset($_POST["nom"]) && isset($_POST["prix"]) && isset($_POST["categorie"]) && isset($_POST["color"]) && isset($_POST["size"])) 
        {
        if(!empty($_POST["ref"]) && !empty($_POST["idd"]) && !empty($_POST["nom"]) && !empty($_POST["prix"]) && !empty($_POST["categorie"]) && !empty($_POST["color"]) && !empty($_POST["size"]))
        {

              $art = new article($_POST["ref"],$_POST["nom"],$_POST["categorie"],$_POST["prix"],$_POST["size"],$_POST["color"],$_POST["img"]);
              $artC->modifierarticle($art,$_POST["idd"]) ;
          ?>             
            <script type="text/javascript">
                window.location = "afficher_articlev.php" ;
            </script>
      <?php

        }
      }

    }

  }

?>

<script src="js/jquery-3.2.1.min.js"></script>
<script src="styles/bootstrap4/popper.js"></script>
<script src="styles/bootstrap4/bootstrap.min.js"></script>
<script src="plugins/Isotope/isotope.pkgd.min.js"></script>
<script src="plugins/OwlCarousel2-2.2.1/owl.carousel.js"></script>
<script src="plugins/easing/easing.js"></script>
<script src="https://maps.googleapis.com/maps/api/js?v=3.exp&key=AIzaSyCIwF204lFZg1y4kPSIhKaHEXMLYxxuMhA"></script>
<script src="plugins/jquery-ui-1.12.1.custom/jquery-ui.js"></script>
<script src="js/contact_custom.js"></script>
</body>

</html>
