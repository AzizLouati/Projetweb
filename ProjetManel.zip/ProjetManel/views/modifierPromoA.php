<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>
    Modifier Promotion
  </title>
  <!-- Favicon -->
  <link href="./assets/img/brand/favicon.png" rel="icon" type="image/png">
  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
  <!-- Icons -->
  <link href="./assets/js/plugins/nucleo/css/nucleo.css" rel="stylesheet" />
  <link href="./assets/js/plugins/@fortawesome/fontawesome-free/css/all.min.css" rel="stylesheet" />
  <!-- CSS Files -->
  <link href="./assets/css/argon-dashboard.css?v=1.1.2" rel="stylesheet" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body class="">
  
 <!-- Header -->
   <?php
       include "headerback.php" ;
       include '../core/promotionAC.php' ;
     if(isset($_POST['ref']) && isset($_POST['id_promo'])) ;
     {
       $promo = new PromotionAC() ;
       $list = $promo->recupererPromotionA($_POST['id_promo']) ;
       if(!empty($list))
       {
        foreach ($list as $row) {
          $photo = $row["photo"] ;
          $prix = $row["prix" ] ;
          $ref = $row["reff"] ;
          $nom = $row["nom"] ;
          $remise = $row['remise'] ;
          $dateDebut = $row['dateDebut'] ;
          $dateFin = $row['dateFin'] ;
          $id_promo = $row['id_promo'] ;
        }
       }
     }
   ?>
        <div class="" style="margin: auto;width: 75%;">
         

            <div class="container-fluid">
          
             <h3 id="dark-table">>Modifier Promotion</h3><br>
            

              <div class="tab-content">
                <div id="table-dark-component" class="tab-pane tab-example-result fade show active" role="tabpanel" aria-labelledby="table-dark-component-tab">

                
                  <caption><h1> </h1></caption><br><br>
                <center><h1 style="color:#b9b4c7;">Modifier Promotion</h1></center><br><br><br>    
               <form method="POST" action="testmodifierpromoA.php" enctype="multipart/form-data">
              <div class="row">
                <div class="col-lg-6">
                    <input class="form-control" type="number" name="idPromo" placeholder="id promotion" value="<?php echo $id_promo ?>" required="required" data-error="id promotion is required."><br><br>
                    <input type="hidden" name="ref" value="<?php echo $ref ?>">
                    <input type="hidden" name="idd" value="<?php echo $id_promo ?>">
                
                  <input class="form-control" type="date" name="dateDebut" placeholder="Date Debut" value="<?php echo $dateDebut ?>" required="required" data-error="date is required."><br><br>

                  
                  <input class="form-control" type="date" name="dateFin" placeholder="Date Fin" value="<?php echo $dateFin ?>" required="required" data-error="Date fin is required."><br><br>
                  
                  
                  <input class="form-control" type="number" name="remise" placeholder="Remise" value="<?php echo $remise ?>" required="required" data-error="Remise is required."><br><br>
                  </div>
                  <div class="col-lg-6">
                    <p style="margin-left: 120px;color: white"><?php echo $nom; ?></p>
                     <img src="uploads/<?php echo $photo ; ?>" style="max-width: 300px;max-height: 350px;">
                     <br>
                     <p style="margin-left: 120px;color: white;margin-top: 20px;"><i style="font-size: 12px;"><s><?php echo $prix; ?> $ </s></i> <span><?PHP echo ($row['prix'] - (($row['prix']*$row['remise'])/100)) ; ?> $</span></p>
                </div>
              </div>

            <div>
                <center><button id="review_submit" type="review_submit" class="btn btn-info" name="modifier" value="Modifier" >
                  Modifier </button></center> 
            </div>

              </form>
 
      </div>
    </div>
  </div>
</div>               
                 
  <!--   Core   -->
  <script src="./assets/js/plugins/jquery/dist/jquery.min.js"></script>
  <script src="./assets/js/plugins/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
  <!--   Optional JS   -->
  <script src="./assets/js/plugins/chart.js/dist/Chart.min.js"></script>
  <script src="./assets/js/plugins/chart.js/dist/Chart.extension.js"></script>
  <!--   Argon JS   -->
  <script src="./assets/js/argon-dashboard.min.js?v=1.1.2"></script>
  <script src="https://cdn.trackjs.com/agent/v3/latest/t.js"></script>
  <script>
    window.TrackJS &&
      TrackJS.install({
        token: "ee6fab19c5a04ac1a32a645abde4613a",
        application: "argon-dashboard-free"
      });
  </script>
</body>
</html>