<?php
  include "../core/promotionC.php" ;
  include  "../entities/promotion.php";
if(isset($_POST["modifier"]))
{
 if( isset($_POST['idPromo']) && isset($_POST['ref'])  && isset($_POST['dateFin']) && isset($_POST['dateDebut']) && isset($_POST['remise']) && isset($_POST['idd']))
        {
          if(!empty($_POST['idPromo']) && !empty($_POST['ref']) && !empty($_POST['dateDebut']) && !empty($_POST['dateFin']) && !empty($_POST['remise']) && !empty($_POST['idd']) )
          {
              $pro=new Promotion($_POST['idPromo'],$_POST['ref'],$_POST['dateDebut'],$_POST['dateFin'],$_POST['remise']);
              $proC = new PromotionC () ;
              $proC->modifierPromotion($pro,$_POST['idd']) ; 
             //header('Location: listePromo.php');
              //echo "string";?>
              <script type="text/javascript">
                alert("promotion modifiée avec success") ;
                window.location="listePromo.php" ;
              </script>
         <?php }
          else { echo "empty" ;}

        }else { echo "empty" ; }
}
?>