<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>
    Liste des clients
  </title>

   <!-- Favicon -->
  <link href="./assets/img/brand/favicon.png" rel="icon" type="image/png">
  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
  <!-- Icons -->
  <link href="./assets/js/plugins/nucleo/css/nucleo.css" rel="stylesheet" />
  <link href="./assets/js/plugins/@fortawesome/fontawesome-free/css/all.min.css" rel="stylesheet" />
  <!-- CSS Files -->
  <link href="./assets/css/argon-dashboard.css?v=1.1.2" rel="stylesheet" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

  <script type="text/javascript">
          function printDiv(divName) {
            var printContents = document.getElementById(divName).innerHTML;
            var originalContents = document.body.innerHTML;

            document.body.innerHTML = printContents;
            window.print();
            document.body.innerHTML = originalContents;
        }

         function trierPar()
         {
          var input = document.getElementById("tri").value  ;
          window.location="listeClient.php?tri="+input;
        }
       </script>
</head>

<body class="">

 <!-- Header -->

        <div class="">
        <?php
           include "headerback.php" ;
           include '../core/clientC.php';
           $clt = new ClientC() ;
           $list=$clt->afficherClient() ; 
           if(isset($_GET['search']))
             {
              $list = $clt->rechercherClient($_GET['search']) ;
             }
          if (!empty($list)) {  ?> 
          <div class="cont" id="divClient">
             <!--<table class="table dark-table" style="margin: auto;width: 95%;text-align: center;" >-->  
             <div class="header bg-gradient-primary pb-8 pt-5 pt-md-8">
 
             <!--<caption><h1> </h1></caption><br><br><br><br> 
              <input type="search" name="search" id="rechercher" onsearch="rechercher() ;" style="margin-bottom: 50px;width: 40%;height: 40px;">  -->

            <div class="container-fluid">
          
             <h3 id="dark-table">Liste des Clients</h3><br>
             <div>

              <div class="tab-content">
                <div id="table-dark-component" class="tab-pane tab-example-result fade show active" role="tabpanel" aria-labelledby="table-dark-component-tab">

                  <form class="navbar-search navbar-search-dark form-inline mr-3 d-none d-md-flex ml-lg-auto">
                    <div class="form-group mb-0">
                      <div class="input-group input-group-alternative">
                        <div class="input-group-prepend">
                          <span class="input-group-text"><i class="fas fa-search"></i></span>
                        </div>
                          <input class="form-control" placeholder="Search" type="search" name="search" id="rechercher" onsearch="rechercher() ;"><br><br>
                      </div>
                    </div>
                     <div style="margin-left: 20px; ">
                    <div class="print">
                        <select style="background:#1c345d; color: #87CEEB; border:none;" id="tri" class="form-control" onchange="trierPar();"> 
                            <option class="fa fa-sliders" value="0">>>Filtrer<<</option>
                            <option class="fa fa-sort-amount-asc" value="id_up">Id Croissant</option>
                            <option class="fa fa-sort-amount-desc" value="id_down">Id Decroissant</option>
                            <option class="fa fa-sort-alpha-asc" value="name_up">Nom A .. Z</option>
                            <option class="fa fa-sort-alpha-desc" value="name_down">Nom Z .. A</option>
                          </select>
                          <i class="fa fa-print "  style="margin-right: 50px; font-size: 28px; color:#32325d; " onclick="printDiv('divClient');"></i>
                    </div>
                </div>
                  </form>
                        <?php
           $cltC = new ClientC() ;
           $mylist=$cltC->afficherClient() ; 
           if(isset($_GET['search']))
             {
              $mylist = $cltC->rechercherClient($_GET['search']) ;
             }

            if(isset($_GET['tri']))
             {
              if($_GET['tri'] == "id_up")
              {
                $mylist= $cltC->TrierClient('id','asc') ;
              }
              else if($_GET['tri'] == "id_down")
              {
                $mylist= $cltC->TrierClient('id','desc') ;
              }
              else if($_GET['tri'] == "name_up")
              {
                $mylist= $cltC->TrierClient('nom','asc') ;
              }
              else if($_GET['tri'] == "name_down")
              {
                $mylist= $cltC->TrierClient('nom','desc') ;
              }
              
             }
         if (!empty($mylist)) {  ?>
          
              <table class="table align-items-center table-dark">
                    <thead class="thead-dark"> 

             
                  <th>ID </th>
                  <th><center><i class="fa fa-user" aria-hidden="true"></i> Nom</center></th>
                  <th><center><i class="fa fa-user-circle" aria-hidden="true"></i> Prenom</center></th>
                  <th><center><i class="fa fa-envelope" aria-hidden="true"></i> Email</center></th>
                  <th><center><i class="fa fa-lock" aria-hidden="true"></i> Mot de Passe</center></th>
                  <th><center><i class="fa fa-map-marker" aria-hidden="true"></i> Addresse</center></th>
                  <th><center><i class="fa fa-phone" aria-hidden="true"></i>Telephone</center></th>
                  <th><center><i class="fa fa-stack-exchange" aria-hidden="true"></i> Action</center></th>
                </thead>
             <tbody>
              <?php
                  foreach ($mylist as $row) {
              ?>
              <tr>
                <td><center><?php echo $row['id'] ; ?></center></td>
                <td><center><?php echo $row['nom'] ; ?></center></td>
                <td><center><?php echo $row['prenom']; ?></center></td>
                <td><center><?php echo $row['email'] ; ?></center></td>
                <td><center><?php echo $row['password'] ; ?></center></td>
                <td><center><?php echo $row['address'] ; ?></center></td>
                <td><center><?php echo $row['phone'] ; ?></center></td>
                <td><center><a style="color: #007bff;" onclick="return confirm('Are you sure you want to Remove?');" href="supprimerClient.php?id=<?PHP echo $row['id']; ?>"><i class="fa fa-trash-o m-r-5"></i></a></center></td>
              </tr>
            <?php
                      }
 
                 }
            ?>
                  <caption><h1> </h1></caption><br><br>
                 
                
          <?php
           }
          ?>
        </tbody>
      </table>
       <?php
           
          ?>
      </div>
  </div>

  <script type="text/javascript">
         function rechercher(){
          var input = document.getElementById("rechercher").value ;
          window.location="listeClient.php?search="+input; 
         }
       </script>

         </table>
                </div>
              </div>
            </div>
           
      
                </div>
                 
           
        </div>


</body>
</html>