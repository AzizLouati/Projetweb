-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: May 27, 2020 at 05:44 AM
-- Server version: 5.7.21
-- PHP Version: 5.6.35

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `projet`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(30) NOT NULL,
  `prenom` varchar(30) NOT NULL,
  `email` varchar(60) NOT NULL,
  `password` varchar(60) NOT NULL,
  `address` varchar(60) NOT NULL,
  `phone` double NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `nom`, `prenom`, `email`, `password`, `address`, `phone`) VALUES
(1, 'admin', 'admin', 'admin@gmail.com', 'admin', 'tunis', 99999999);

-- --------------------------------------------------------

--
-- Table structure for table `article`
--

DROP TABLE IF EXISTS `article`;
CREATE TABLE IF NOT EXISTS `article` (
  `ref` int(250) NOT NULL,
  `nom` varchar(100) NOT NULL,
  `categorie` varchar(100) NOT NULL,
  `prix` int(100) NOT NULL,
  `size` varchar(100) NOT NULL,
  `color` varchar(12) NOT NULL,
  `photo` varchar(250) NOT NULL,
  `etatPromo` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `article`
--

INSERT INTO `article` (`ref`, `nom`, `categorie`, `prix`, `size`, `color`, `photo`, `etatPromo`) VALUES
(63, 'tshirt', 'men', 852, 'S', 'Black', 'desc_2.jpg', 0),
(22, 'robe', 'men', 85, 'm', 'bleu', 'banner_1.jpg', 1);

-- --------------------------------------------------------

--
-- Table structure for table `articlea`
--

DROP TABLE IF EXISTS `articlea`;
CREATE TABLE IF NOT EXISTS `articlea` (
  `ref` int(250) NOT NULL,
  `nom` varchar(100) NOT NULL,
  `categorie` varchar(100) NOT NULL,
  `prix` int(100) NOT NULL,
  `size` varchar(100) NOT NULL,
  `color` varchar(12) NOT NULL,
  `photo` varchar(250) NOT NULL,
  `etatPromoA` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `articlea`
--

INSERT INTO `articlea` (`ref`, `nom`, `categorie`, `prix`, `size`, `color`, `photo`, `etatPromoA`) VALUES
(87, 'pull', 'men', 256, 'l', 'bleu', 'product_10.png', 1),
(45, 'jupe', 'women', 150, 's', 'rouge', 'product_5.png', 0),
(14, 'robe', 'women', 214, 'm', 'rouge', 'product_1.png', 1);

-- --------------------------------------------------------

--
-- Table structure for table `client`
--

DROP TABLE IF EXISTS `client`;
CREATE TABLE IF NOT EXISTS `client` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(30) NOT NULL,
  `prenom` varchar(30) NOT NULL,
  `email` varchar(60) NOT NULL,
  `password` varchar(60) NOT NULL,
  `address` varchar(60) NOT NULL,
  `phone` double NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `client`
--

INSERT INTO `client` (`id`, `nom`, `prenom`, `email`, `password`, `address`, `phone`) VALUES
(1, 'baabou', 'manel', 'manel@gmail.com', 'baabou', 'tunis', 98541254),
(2, 'patch', 'work', 'work@gmail.com', 'patchwork', 'ariana', 98745814);

-- --------------------------------------------------------

--
-- Table structure for table `promotion`
--

DROP TABLE IF EXISTS `promotion`;
CREATE TABLE IF NOT EXISTS `promotion` (
  `id_promo` int(11) NOT NULL,
  `dateDebut` date NOT NULL,
  `dateFin` date NOT NULL,
  `remise` int(11) NOT NULL,
  `ref` int(11) NOT NULL,
  PRIMARY KEY (`id_promo`),
  KEY `fr_ref_art` (`ref`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `promotion`
--

INSERT INTO `promotion` (`id_promo`, `dateDebut`, `dateFin`, `remise`, `ref`) VALUES
(1, '2020-05-05', '2020-09-10', 17, 22),
(33, '2020-05-30', '2020-06-27', 50, 22),
(80, '2020-06-07', '2020-06-22', 5, 87),
(25, '2020-06-14', '2020-05-20', 12, 87);

-- --------------------------------------------------------

--
-- Table structure for table `promotiona`
--

DROP TABLE IF EXISTS `promotiona`;
CREATE TABLE IF NOT EXISTS `promotiona` (
  `id_promo` int(11) NOT NULL,
  `dateDebut` date NOT NULL,
  `dateFin` date NOT NULL,
  `remise` int(11) NOT NULL,
  `ref` int(11) NOT NULL,
  PRIMARY KEY (`id_promo`),
  KEY `fr_ref_art` (`ref`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `promotiona`
--

INSERT INTO `promotiona` (`id_promo`, `dateDebut`, `dateFin`, `remise`, `ref`) VALUES
(74, '2020-05-30', '2020-06-10', 25, 87),
(85, '2020-05-23', '2020-07-11', 5, 14);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
