<?php
class articleA
{
	private $ref;
	private $nom;
	private $categorie;
	private $prix;
	private $size;
	private $color;
	private $photo;
	public function __construct($ref,$nom,$categorie,$prix,$size,$color,$photo) /*constructeur*/
	{
		$this->ref=$ref;$this->nom=$nom;$this->categorie=$categorie;$this->prix=$prix;$this->size=$size;$this->color=$color;$this->photo=$photo;
	
	}
	public function getref() {return $this->ref;}
	public function setref($ref) {$this->ref=$ref;}
	public function getnom() {return $this->nom;}
	public function setnom($nom) {$this->nom=$nom;}
	public function getcategorie() {return $this->categorie;}
	public function setcategorie($categorie) {$this->categorie=$categorie;}
	public function getprix() {return $this->prix;}
	public function setprix($prix) {$this->prix=$prix;}
	public function getsize() {return $this->size;}
	public function setsize($size) {$this->size=$size;}
	public function getcolor() {return $this->color;}
	public function setcolor($color) {$this->color=$color;}
	public function getphoto() {return $this->photo;}
	public function setphoto($photo) {$this->photo=$photo;}
	
	
}
?>