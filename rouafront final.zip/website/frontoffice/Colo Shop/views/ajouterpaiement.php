<?PHP
session_start();
include "C:/wamp64/www/website/frontoffice/Colo Shop/entities/paiement.php";
include "C:/wamp64/www/website/frontoffice/Colo Shop/core/paiementc.php";


if (isset($_POST['name']) &&  isset($_POST['email']) && isset($_POST['num_cart']) && isset($_POST['date']) && isset($_POST['cvc'])){
$paiement1=new paiement($_SESSION['id'],$_POST['name'],$_POST['email'],$_POST['num_cart'],$_POST['date'],$_POST['cvc']);

$paiement1c=new paiementc();

 $verif=$_SESSION['id'];
  
  $sql="select * from carte where idclient=$verif";    
    $db=config :: getConnexion();
try 
    {
  $liste=$db->query($sql);
  
    }
    catch (Exception $e)
    {echo 'Echec' .$e->getMessage();}
  
  foreach($liste as $row )

     {   
   		$nom=$row['nom'];
		$email=$row['email'];
		$num_cart=$row['num_cart'];	
		$date=$row['date'];	
		$cvc=$row['cvc'];			

     }
     if(($nom==$_POST['name']) && ($email==$_POST['email']) && ($num_cart==$_POST['num_cart']) && ($date==$_POST['date']) && ($cvc==$_POST['cvc'])){
     	$paiement1c->ajouterpaiement($paiement1);
     	$_SESSION['nomf']=$_POST['name'];
     	$_SESSION['emailf']=$_POST['email'];
     	$_SESSION['num_cartf']=$_POST['num_cart'];

     	
	echo "<script>
alert('ajout avec succes');
window.location.href='telechargement.html';
</script>";
		
}/*else{
	echo "<script>
alert('erreur');
window.location.href='paiement.html';
</script>";
}*/


	
}

?>