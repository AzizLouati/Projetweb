<?php
	require_once "stripe-php-master/init.php";


	$stripeDetails = array(
		"secretKey" => "sk_test_UyGOFESdBdhmN6TtUwAY3Knn00fbOUdEE4",
		"publishableKey" => "pk_test_vGTwU9sP00teaZFgBqyQsLdP00T4P7CkDW"
	);

	// Set your secret key: remember to change this to your live secret key in production
	// See your keys here: https://dashboard.stripe.com/account/apikeys
	\Stripe\Stripe::setApiKey($stripeDetails['secretKey']);
?>
