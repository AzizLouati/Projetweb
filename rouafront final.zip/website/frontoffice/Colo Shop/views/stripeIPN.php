<?php
session_start();
	require_once "configstripe.php";
	include "../core/paiementc.php";

	\Stripe\Stripe::setVerifySslCerts(false);

	// Token is created using Checkout or Elements!
	// Get the payment token ID submitted by the form:
	

	if (!isset($_POST['stripeToken']) ) {
		exit();
	}

	$token = $_POST['stripeToken'];
	$email = $_POST["stripeEmail"];
	 $_SESSION['emailf']=$email;
	// Charge the user's card:
	$charge = \Stripe\Charge::create(array(
		"amount" => $_SESSION['total']*100,
		"currency" => "usd",
		"description" => "aaa",
		"source" => $token,
	));

	//send an email
	//store information to the database
	echo 'Success! ';
	$sql="insert into paiement (idclient,name,email,date,prix) values (:idclient,:name,:email,:date,:prix)";
		$db = config::getConnexion();
		try{
        $req=$db->prepare($sql);
		$date = date('Y-m-d H:i:s');
        $req->bindValue(':idclient',$_SESSION['id']);
		$req->bindValue(':name',$_SESSION['nom']);
		$req->bindValue(':email',$email);
		$req->bindValue(':date',$date);
		$req->bindValue(':prix',$_SESSION['total']);
            $req->execute();
           }
        
        catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
       
		
	header('Location: telechargement.html');

?>