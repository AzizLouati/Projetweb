<?php
session_start();
 include "./../../../config.php";
if (isset($_POST['tele'])) {

  
  $sql="select * from panier";    
    $db=config :: getConnexion();
try 
    {
  $liste=$db->query($sql);
  
    }
    catch (Exception $e)
    {echo 'Echec' .$e->getMessage();}
 
ob_start();
     	?>
     	<br>
     	<center >
     		 <h3 style="text-align: center; color: #f0a8a8;margin-top: 50px;">votre facture</h3>
     	<fieldset style="text-align: center;border-width: 3px;border-style: solid; border-color: grey;">
     		
     	<p>votre nom :<?php echo $_SESSION['nom'] ;?></p>
     	<p>votre nom :<?php echo $_SESSION['emaill'] ;?></p>
     	<p>-----------------------------------------------------</p>
     	
     	<table style="border-width: 5px;margin-left: 35%;">
     	<tr>
                        <th scope="col" class="sort" data-sort="name">ref</th>
                        <th scope="col" class="sort" data-sort="status">quantité</th>
                        <th scope="col" class="sort" data-sort="budget">nom</th>
                        <th scope="col" class="sort" data-sort="status">prix</th>
    
                      </tr>
     		<?php
           foreach($liste as $row )

           {   
            ?>
                    
                      <tr>
                        <td >
                         <?php echo $row['ref'];?>
                        </td>
                         <td>
                        <?php echo $row['quantite'];?>
                        </td>
                        <td>
                          <?php echo $row['nom'];?>
                        </td>
                        <td>
                        <?php echo $row['prix'];?>dt
                        </td>
                       
                          </tr>
                         

           <?php } ?>
                    
     	</table>
     	<p> prix a payer :<?php echo$_SESSION['total'];?>dt</p>
     	<br>
     	<br>
     	<p style="color: grey;">---------------------------------------------------------</p>
     	<p>votre commande va être livrer dans 2jours</p>
     	<p>Merci de votre achat et d’avoir choisi PatchWork!</p>
     	<p>Suivez nos dernières tendances, actualités et promotions !</p>
     	<p style="color: #f0a8a8; ">contact us :</p>
     	<p>email:patchwork@patchwork.com</p>
     	<p>numero:(216) 28020202</p>
		</fieldset>
		</center>
     	<?php
     	$body=ob_get_clean();
     	$body = iconv("UTF-8","UTF-8//IGNORE",$body);
     	include "../mpdf/mpdf.php";
     	 $mpdf=new \mPDF('c','A4','','' , 0, 0, 0, 0, 0, 0); 
     	 $mpdf->WriteHTML($body);
     	 $mpdf->Image('logo.png', 5, 0, 45, 21, 'png', '', true, false);
		$mpdf->Output('facture.pdf','D');
	}
?>