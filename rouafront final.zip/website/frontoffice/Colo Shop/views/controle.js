function verifnom(){
	var nom=document.getElementById('input_name').value;
	if(nom==''){
		document.getElementById('erreur_nom').innerHTML="veuillez remplir ce champ";
	}else{
	document.getElementById('erreur_nom').innerHTML="";}
	
}
function verifcvc(){
	var cvc=document.getElementById('cvc').value;
	if(cvc==''){
		document.getElementById('erreur_cvc').innerHTML="la taille du champs doit etre 4";
	}else
		document.getElementById('erreur_cvc').innerHTML="";

}
function verifcard(){
	var card=document.getElementById('input_num').value;
	if(card.toString().length<=16){
		document.getElementById('erreur_card').innerHTML="le numero de la carte doit contenir 16 chiffres";
	}else
		document.getElementById('erreur_card').innerHTML="";
}
function verifdate()
{
	var today2=new Date();
	var expiration=document.getElementById("input_date").value;
	var date_liv=new Date(expiration);
	if(date_liv<today2){
	document.getElementById('erreur_date').innerHTML="erreur la date doit etre superieur a la date acutelle";
	return false;}
	else 
		document.getElementById('erreur_date').innerHTML="";
		return true;

}
function valider()
{
	if((verifnom())&&(verifcvc())&&(verifdate())&&(verifcard()))
		alert("Success");
}
