<?PHP
class paiement{
	private $idclient;
	private $name;
	private $email;
	private $num_cart;
	private $date;
	private $cvc;
	function __construct($idclient,$name,$email,$num_cart,$date,$cvc){
		$this->idclient=$idclient;
		$this->name=$name;
		$this->email=$email;
		$this->num_cart=$num_cart;
		$this->date=$date;
		$this->cvc=$cvc;
	}
	function getidclient(){
		return $this->idclient;
	}
	function getname(){
		return $this->name;
	}
	function getemail(){
		return $this->email;
	}
	function getnum_cart(){
		return $this->num_cart;
	}
	function getdate(){
		return $this->date;
	}
	function getcvc(){
		return $this->cvc;
	}
	
	function setname($name){
		$this->name=$name;
	}
	function setemail($email){
		$this->email=$email;
	}
	function setnum_cart($num_cart){
		$this->num_cart=$num_cart;
	}
	function setdate($date){
		$this->date=$date;
	}
	function setcvc($cvc){
		$this->cvc=$cvc;
	}
}
	?>