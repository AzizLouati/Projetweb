<?php
class client{
	private $id;
	private $nom;
	private $mdp;
	private $email;
	function __construct($id,$nom,$mdp,$email){
		$this->id=$id;
		$this->nom=$nom;
		$this->mdp=$mdp;
		$this->email=$email;
	}
	function getid(){
		return $this->id;
	}
	
	function getnom(){
		return $this->nom;
	}
	
	function getmdp(){
		return $this->mdp;
	}
	function getemail(){
		return $this->email;
	}

	function setnom($nom){
		$this->nom=$nom;
	}
	
	function setmdp($mdp){
		$this->mdp=$mdp;
	}
	
}


?>