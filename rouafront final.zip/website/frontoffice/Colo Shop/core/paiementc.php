<?php
include "C:/wamp64/www/website/config.php";
class paiementC {
	function ajouterpaiement($paiement){
		$sql="insert into paiement (idclient,name,email,date,cvc) values (:idclient,:name,:email,:num_cart,:date,:cvc)";
		$db = config::getConnexion();
		try{
        $req=$db->prepare($sql);
		$idclient=$paiement->getidclient();
        $name=$paiement->getname();
        $email=$paiement->getemail();
        $num_cart=$paiement->getnum_cart();
        $date=$paiement->getdate();
        $cvc=$paiement->getcvc();
        $req->bindValue(':idclient',$idclient);
		$req->bindValue(':name',$name);
		$req->bindValue(':email',$email);
		$req->bindValue(':num_cart',$num_cart);
		$req->bindValue(':date',$date);
		$req->bindValue(':cvc',$cvc);
            $req->execute();
           
        }
        catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
       
		}
	}


?>