<?php
include "C:\wamp64\www\website\config.php";
class clientC {
	function login($client){
		$id=$client->getid();
		$sql="SELECT * from client where id=$id";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }

	}

}



?>